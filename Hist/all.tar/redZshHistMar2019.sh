  100  tmuxinator start kBank2
  101  tmuxinator start kBank20
  102  uptime
  103  netstat
  104  ping localhost
  105  cd /home/red/git/aTest/dotFiles
  106  cd var
  107  top
  108  cd log
  109  lsof
  110  man lsof
  111  nvim
  112  zsh
  113  ni ninitOkt18.vim kTmux19.conf kBank19.yml
  114  tmux kill-server
  115  tmux
  116  tmuxinator start kBank19
  117  tail /var/log/mysql
  118  cd /home/red/git/aTest/dotFiles/nVim
  119  nvim pdbA/FindMax.py
  120  fish
  121  whoami
  122  nvim 50%
  123  ustime
  124  sh
  125  mysql -u root -p mypass
  126  mysql -u root -p
  127  tail /var/log/mysql/error.log
  128  tail /var/log/syslog
  129  tail /var/log/auth.log
  130  tail /var/log/boot.log
  131  tail /var/log/dpkg.log
  132  sudo
  133  h language
  134  history | vim -
  135  ni ninitOkt18.vim
  136  cd ../../pyLabGitPdbPythonMode27/
  137  ni 01sympyRu.py
  138  mv startNinit19.vim start1ninit19.vim
  139  ni ninitOkt18.vim start1ninit19.vim
  140  ni2
  141  ni2 start1ninit19.vim
  142  vim ninitOkt18.vim start1ninit19.vim minit.vim
  143  cp ninitOkt18.vim lego-nini.vim
  144  mv start1ninit19.vim 1startNinit19.vim
  145  vi minit.vim
  146  ni 1startNinit19.vim
  147  ni minit.vim
  148  vi tags
  149  cp ../../../pyLabGitPdbPythonMode27/00velocity_ex_08_01.py .
  150  cp ../../../pyLabGitPdbPythonMode27/50calculator.py .
  151  ctags *.py
  152  ni tags
  153  ni minit.vim 1startNinit19.vim lego-nini.vim
  154  cd ~/.config/nvim/plugged
  155  ni delimitMate/README.md
  156  ni pydoc.vim/README
  157  pydoc class
  158  chmod u+x nvim.appimage && ./nvim.appimage
  159  chmod u+x nvim.appimage
  160  chmod u+x nvim
  161  ./nvim
  162  kill 20297
  163  man pyls
  164  locate pyls
  165  vlf
  166  vlc
  167  firefox
  168  man snap
  169  git add kIng19.sh kTmux19.conf kZshrc19 historyRedRoot.txt
  170  git add * *.vim
  171  git add *.yml
  172  cd ~/nvim-linux64/bin
  173  py
  174  pyls
  175  cc
  176  nvim -u ~/git/aTest/dotFiles/nVim/minit.vim
  177  ./nvim -u ~/git/aTest/dotFiles/nVim/minit.vim


  114  tmux kill-server
  116  tmuxinator start kBank19
  172  cd ~/nvim-linux64/bin
  178  cp nvim deonvim
  179  ./deonvim -u ~/git/aTest/dotFiles/nVim/minit.vim
  180  rm nvim
  181  rm deoplete.log
  182  cp -r nVim deo4mix74DeoVsYcmSnipUnite
  183  cp -r deo4mix74DeoVsYcmSnipUnite /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  184  cd .fzf/bin/
  185  .fzf -q vim$
  186  ls fzf
  187  vi fzf
  188  whereis fzf
  189  fzf -q vim$
  190  cd git/aTest/dotFiles/nVim
  191  ni 50calculator.py
  192  ni1
  193  cp -r nVim deo5mix75DeoVsYcmSnipUniteFZF
  194  cp -r deo5mix75DeoVsYcmSnipUniteFZF /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  195  cp -r nVim deo6mix76DeoVsYcmSnipUniteFzfEchoDoc
  196  cp -r deo6mix76DeoVsYcmSnipUniteFzfEchoDoc /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  197  mv taghl_config.txt marsh-taghl_config.txt
  198  cp -r nVim deo7mix77DeoVsYcmSnipUniteFzfEchoDocHiTag
  199  cp -r deo7mix77DeoVsYcmSnipUniteFzfEchoDocHiTag /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  200  ni minit.vim 1startNinit19.vim nProtoFzfDeoLsJediSnip.vim
  201  cp -r nVim deo8mix78DeoVsYcmSnipUniteFzfEchoDocHiTag
  202  deo minit.vim 1startNinit19.vim nProtoFzfDeoLsJediSnip.vim
  203  ls logo
  204  ls logo*
  205  git mv legoCyan.vim logoCyan.vim
  206  deo minit.vim 1startNinit19.vim nProtoFzfDeoLsJediSnip.vim lego-nini.vim
  207  trans hallo
  208  z
  209  cp -r nVim deo9mix79DeoVsYcmSnipUniteFzfEchoDocHiTagGit
  210  cp -r deo9mix79DeoVsYcmSnipUniteFzfEchoDocHiTagGit /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  211  ls err
  212  ls *err*
  213  rm 'Closes all but the current window'
  214  deo minit.vim nProtoFzfDeoLsJediSnip.vim logo1.vim
  215  deo minit.vim nProtoFzfDeoLsJediSnip.vim logo1.vim lego-nini.vim
  216  cp -r nVim deo10mix80DeoVsYcmSnipUniteFzfEchoDocHiTagGitSS
  217  cp -r deo10mix80DeoVsYcmSnipUniteFzfEchoDocHiTagGitSS /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  218  deo -v
  219  deo -v | vim -
  220  vim -v | vim -
  221  vim -v | neo -
  222  vim -v | deo -
  223  vim --V
  224  vi foo.vim/README
  225  vi foo.vim/plugin/foo.vim
  226  ctags *.vim
  227  ni nFoo.vim
  228  deo minit.vim nProtoFzfDeoLsJediSnip.vim lego-nini.vim
  229  cp nProtoFzfDeoLsJediSnip.vim DEO2.vim
  230  ne lista.nvim/README.md
  231  deo python-support.nvim/README.md
  232  deo vim-textobj-python/README.md
  233  deo vim-zebra
  234  deo minit.vim DEO2.vim lego-nini.vim
  235  vi FuzzyFinder/README
  236  vi bash-support/README.md
  237  neo noPlug.vim
  238  vi vim-imagine/README.md
  239  deo noPlug.vim
  240  vi notational-fzf-vim/README.md
  241  cd git
  242  mkdir vim82
  243  cd vim82
  244  git clone https://github.com/vim/vim.git
  245  cd vim
  247  kill 4980
  248  deo README.md
  249  deo README.txt
  250  deo src/README.txt
  251  vim -V
  252  vim --v
  253  vim -v
  254  vim -Version
  255  vim -h
  256  vim --version
  257  deo READMEdir/README_unix.txt
  258  cd vim82/vim/src
  259  deo INSTALL
  260  ls /home/red/82vim
  261  cd git/vim82/vim/src
  262  ./configure --prefix =/home/red/82vim
  263  deo minit.vim DEO2.vim lego-nini.vim logoTextObjct.vim nMakeInstallVim82.vim
  264  ne Makefile
  265  cd 82vim
  266  cd ~/82vim
  267  ls share
  268  ls share/vim
  269  ls share/vim/vim81
  270  ls share/vim/vim81/plugin
  271  vim
  272  ./vim testNewVim81.txt

  273  cd vim-master-82/src
  261  cd git/vim82/vim/src
  262  ./configure --prefix =/home/red/82vim
  275  make install
  275  make install
  263  deo minit.vim DEO2.vim lego-nini.vim logoTextObjct.vim nMakeInstallVim82.vim

  273  cd vim-master-82/src
  275  make install
  276  cd 82vim/bin
  277  ./vim --version
  278  ./vim
  279  python -V
  280  python3 -V
  281  python3 -h
  282  deo lista.nvim/README.md
  283  cd vim-gitgutter
  284  rm README.mkd
  285  deo minit.vim DEO2.vim lego-nini.vim logoTextObjct.vim
  286  deo minit.vim DEO2.vim
  287  deo minit.vim nProtoFzfDeoLsJediSnip.vim DEO2.vim
  288  cp nProtoFzfDeoLsJediSnip.vim DEO3.vim
  289  deo minit.vim DEO3.vim DEO2.vim
  291  cd Music/Komodo-Edit-11.1.1-18206-linux-x86_64
  292  ./install.sh
  294  pw
  295  deo python-mode/readme.md
  296  kill 20606
  298  cp -r nVim deo11mix81DEO3
  299  vi
  300  deo minit.vim DEO3.vim nAsyncRun.vim nAsync.vim
  301  mv aSilverPyVim.py pSilverPyVim.py
  302  ni nPyJedi.vim nPyPipExtra.vim nPythonSuport.vim nPy.vim
  303  deo Py.vim nPyJedi.vim nPyPipExtra.vim nPythonSuport.vim
  304  deo nPy.vim nPyJedi.vim nPyPipExtra.vim nPythonSuport.vim
  305  deo minit.vim DEO3.vim nPyAgSearch.vim
  306  deo minit.vim DEO3.vim pEvalCurrLine.py
  307  cd '/media/red/F1E8-C819/hTML-Zp-Link/2019CollectZip/dotfiles-master-vimPlusPythons/zsh'
  308  fzf silver
  309  deo minit.vim DEO3.vim BOX.todo
  310  fzf python3
  311  fzf python3 *.vim
  312  cd ~
  313  neo
  314  cd /media/red/F1E8-C819
  315  cd hTML-Zp-Link
  316  cd /
  317  cd media/red/F1E8-C819/hTML-Zp-Link
  318  cp -r nVim deo12mix82DEO3-endPython1pBOX
  319  mv deo12mix82DEO3-endPython1pBOX /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  320  deo pBOX.vim
  321  ls *.py
  322  rm pEvalCurrLine.py
  323  :wa
  324  cp -r nVim deo13mix83DEO3-2pBOX
  325  mv deo13mix83DEO3-2pBOX /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  326  clear
  327  cp -r nVim deo14mix84DEO3-3pBOX10
  328  mv deo14mix84DEO3-3pBOX10 /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  329  ni absMax.py abs.py FindMax.py find_hcf.py
  330  cd pyLabGitPdbPythonMode27
  331  deo minit.vim DEO3.vim pBOX.vim pSYMPY01.py logoCyan.vim
  332  deo 50calculator.py
  333  cd dotFiles/nVim/swamPython3
  334  echo $PATH
  335  deo mypolygon.py
  336  chmod u+x hello.go
  337  ./hello.go
  338  de hello.go
  339  ni hello.go
  340  go run hello.go
  341  deo minit.vim DEO3.vim pBOX.vim pSYMPY01.py hello.go
  342  go run main.go
  343  deo minit.vim DEO3.vim pBOX.vim pSYMPY01.py main.go
  344  man pydbgp
  345  mv mypolygon.py myPolyCtr.py
  346  git add *.sh
  347  git add *.lua
  348  git add *.pl
  349  git add hello.go
  350  cd ~/.config/nvim/
  351  ls ftdetect
  352  ls rplugin
  353  ls rplugin/python/
  354  ls rplugin/python3
  355  ls spell
  356  deo testvimpyrc.vim
  357  deo minit.vim DEO3.vim pBOX.vim pSYMPY01.py p3Simple.py
  358  cd git/aTest/dotFiles/
  359  cp -r nVim deo15mix85DEO3-3pBOX11PyGo
  360  deo minit.vim DEO3.vim pBOX.vim pSYMPY01.py tst.vim
  361  ni vim_bridge/README.rst
  362  ni gom/README.mkd
  363  ni vim-zoom/README.md
  364  mkdir goLang
  365  deo minit.vim DEO3.vim pBOX.vim pSYMPY01.py goLang/epoch/main.go
  366  deo minit.vim DEO3.vim pBOX.vim pSYMPY01.py goLang/epoch.go
  367  cd goLang
  368  rm -r epoch
  369  mv goLang goLab
  370  git add goLab/
  371  git add *.go
  372  ni nGO.vim
  373  deo goBOX.todo
  374  mkdir cLab
  375  deo minit.vim DEO3.vim pBOX.vim pSYMPY01.py
  376  gcc -c first.c
  377  deo first.c
  378  gcc -c first.c -o first.o
  379  chmod u+x first.o
  380  ./first.o
  381  g++ -o gunia first.o
  382  ./gunia
  383  vi gunia
  384  pVimPy.vim
  385  deo pVimPy.vim
  386  man go
  387  go version
  388  go env
  389  which godef
  390  which go
  391  go get -u github.com/nsf/gocode
  392  which gocode
  393  go get -u github.com/jstemmer/gotags
  394  go get -u code.google.com/p/rog-go/exp/cmd/godef
  395  go get -u -v github.com/golang/lint/golint
  396  go get -u -v golang.org/x/tools/cmd/guru
  397  go get -u -v golang.org/x/tools/cmd/goimports
  398  go get -u -v golang.org/x/tools/cmd/gorename
  399  ls bin
  400  deo testThis.go
  401  deo epoch.go
  402  deo hello.go
  403  deo DEO3.vim
  404  git add goBOX.todo BOX.todo
  405  git push
  406  deo DEO3.vim minit.vim
  408  deo DEO3.vim minit.vim pSYMPY01.py
  409  fzf python *.vim
  410  fzf
  411  man fzf
  412  man exa
  413  cd ultisnips/
  414  ls utils
  415  ls test
  416  cd vim-snippets
  417  ls UltiSnips
  418  ls snippets
  419  vi README.md
  420  vi UltiSnips/all.snippets
  421  cd .config/nvim/plugged
  422  cd neosnippet-snippets
  423  ls neosnippets
  424  cd neosnippets
  425  vim vim.snip
  426  cp first.c noFirst.cpp
  427  cp first.c noFirst.h
  428  cp first.c noFirst.cc
  429  deo ultiBOX.py
  430  deo ultiBOX.vim
  431  mv ultiBOX.vim nVim
  432  cp -r nVim deo16mix86DEO3-UltiBigFont
  433  cp -r deo16mix86DEO3-UltiBigFont /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  434  deo minit.vim DEO3.vim pSYMPY01.py
  435  brexit.py
  436  deo brexit.py
  437  mkdir goLab
  438  cd ~/git/aTest/dotFiles/nVim/
  439  ni kZshrc19
  440  mkdir go
  441  rm -r goLab
  442  bash
  443  cd go
  444  cd ~/go
  445  deo test.go
  447  deo minit.vim DEO3.vim pSYMPY01.py pVimPy.vim pBOX.vim
  448  cp -r nVim deo17mix87DEO3-RUBY01
  449  mv deo17mix87DEO3-RUBY01 /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  450  ls myPy4Vim
  451  cd pdbA
  452  deo Robot.py
  453  cd ~/git/aTest/dotFiles/nVim/pdbA
  455  deo DateTime.py
  456  cd Music/DocFetcher-1.1.22
  457  deo Readme.txt
  458  ./DocFetcher-GTK3.sh
  459  cd ~/Music/cream-0.43
  460  ni docs/README.txt
  461  ./INSTALL.sh
  462  chmod u+x cream
  463  ./cream
  464  htop
  465  cd ~/Music/LJArchive2017
  466  cp 'Start Linux.sh' Linux.sh
  467  chmod u+x Linux.sh
  468  ./Linux.sh
  469  cd ~/Music/
  470  ls -l | awk '$1 !~ /total/ { printf "%-32s %s\n",$9,$5 ; }'
  471  deo AWK.sh
  472  ls | xargs -n 2 echo ===
  473  ls | xargs -n 2 echo
  474  ls | xargs echo
  475  ls | xargs -n 3 echo
  476  ls | xargs -n 4 echo
  477  ls | xargs -n 4 echo :::
  478  ls | xargs -n 3 echo :::
  479  ls | grep '^pope' | xargs -n 3 echo ::
  480  ls | grep 'tpope' | xargs -n 3 echo ::
  481  ls | grep 'master' | xargs -n 3 echo ::
  482  df -k
  483  df -kh
  484  df -kh /dev/sd*
  485  df -kh /
  486  cd tpope-master
  487  awk "{ print ; }" .zshrc
  489  cp .vimrc pope-vimrc
  490  cp .zshrc pope-ZSHrc
  491  cp .gitconfig pope-gitconfig
  492  deo pope-vimrc
  493  cd
  494  cd ~/git/aTest/dotFiles/
  495  cp -r nVim deo18mix88DEO3-AWK01
  496  cp -r deo18mix88DEO3-AWK01 /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  497  mkdir awkLab
  498  deo fruchte.txt
  499  sed '/0\.[0-9][0-9]$/p' fruchte.txt
  500  deo SedAWK.sh
  501  cd git/aTest/dotFiles/nVim/
  502  ni DEO3.vim ninitOkt18.vim
  503  deo DEO3.vim ninitOkt18.vim
  504  deo printargs.py
  505  python3 printargs.py
  506  python3 printargs.py hello world
  507  python3 sortstdin.py < cities.txt
  508  python3 crtPath.py
  509  python3 date-date.py
  510  python3 inter.py
  511  python3 sub.py
  512  deo tMath.py
  513  deo laplace.py
  514  deo cMath.py tMath.py
  515  deo LEGB.py
  516  mkdir gitConf
  517  cd gitConf
  518  deo blobGitConf
  519  git add *.py
  520  mv AWK.sh awkLab
  521  ga awkLab/
  522  cd awkLab
  523  ga *.sh
  524  ga *.txt
  525  git add swamPython3/
  526  ls cLab
  527  ga cLab/
  528  cd cLab
  529  de testSnip.vim
  530  deo testSnip.vim
  531  git add *.c
  532  git add *.cc
  533  git add *.cpp
  534  git add *.h
  535  git add *.vim
  536  git add rubyBOX.todo
  537  ls goLab
  538  ga *.todo
  539  rm -r bin
  540  rm -r src
  541  cd ../../gitConf
  542  deo helmGitConf
  543  ga *Conf
  544  ma rm
  545  man rm
  546  cd nVim
  547  cd goLab
  548  rm -fr src
  550  snap list
  551  zeal
  552  pip3 install multiprocessing
  553  deo thrOne.py
  554  deo thr00.py
  555  deo thr40Ping.py
  556  deo sub.py
  557  deo sym00Quadr.py
  558  cd git/Jython
  559  java -jar jython_installer-2.7.0.jar\n
  560  deo 00Jyton.py
  561  mkdir cYthon
  562  deo hello.pyx test.py setup.py
  563  python test.py
  564  python3 test.py
  565  mkdir torch
  566  deo 00testTorch.py
  567  cp -r dotFiles 9Marz19dotFiles
  568  cp -r 9Marz19dotFiles /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  569  cd nVim/pdbA
  570  mkdir tensor
  571  man jython
  572  cython --version
  573  man cython
  574  mkdir floop
  575  deo fastloop.pyx
  576  firefox fastloop.html
  577  ./fastloop.so
  578  deo fastloop.c
  579  deo MemoryUvsMasU.vim
  581  cd floop
  582  deo rbf.py
  583  cython fastloop.pyx -a
  584  deo testFastLoop.py
  585  mkdir fib
  586  cd fib
  587  deo fib.pyx
  588  deo fib.pyx setup.py testFib.py
  589  mkdir pythagor
  590  deo pythagor.py
  591  cp pythagor.py pythagor.pyx
  593  deo main.py
  594  mkdir nastyImg
  595  cd nastyImg
  596  deo nastyFild.py
  597  python nastyFild.py
  598  ./nastyFild.py
  600  mkdir mandel3
  601  cd mandel3
  602  deo mandel3cy.pyx setup.py appView.py
  603  deo appNoWX.py
  604  imagej mandelbrot.png
  605  rm mandel3cy.pyx
  606  deo mandelcy.pyx appNoWX.py setup.py
  607  python setup.py build_ext --inplace
  608  mv mandelbrot.png 1mandelbrot.png
  609  python appNoWX.py
  610  imagej mandelbrot.png 1mandelbrot.png
  611  cython mandelcy.pyx -a
  612  firefox mandelcy.html
  613  lspci -v | vim -
  614  lscpu
  615  deo 01tensor.py
  616  mv 00tensor.py tensor
  617  cd tensor
  620  history | grep jython
  621  java -jar jython-installer-2.7.0.jar\n
  622  cd git/aTest/dotFiles/nVim/pdbA
  623  ls javaBsp
  624  ls javaJUnit
  625  cp javaJUnit/HelloWorld.java dotFiles/nVim/pdbA
  627  lc
  628  rm 'HelloWorld*\nls
  629  rm 'HelloWorld*'
  630  rm *.class*
  631  deo HelloWorld.java
  632  jython 00Jyton.py a
  633  jython --version
  634  jython --h
  635  jython -h
  636  echo $PYTHONPATH
  637  echo $JYTHONPATH
  638  python
  639  cython
  640  cd inkVim
  641  deo vim-inkAutoGroupAutoCommand.vim vim-experemental.vim ex-2mashine.vim
  642  whereis firefox
  643  deo 00tensor.py
  644  deo minit.vim DEO3.vim pBOX.vim
  645  mkdir mysql
  646  deo testMyCon.py
  647  go get github.com/lib/pq
  648  deo ruby1MySQL.rb
  649  deo php1MyTest.php
  650  php -v
  651  mv cpp1MySQL.cpp c1MySQL.c
  652  cp c1MySQL.c test.c
  653  deo prepCppMySQL.vim
  654  deo java1MySql.java
  655  sqlitebrowser
  656  deo python1TestLight.py
  657  cd Jython
  658  deo hello.py main.py
  659  java -jar jython-standalone-2.7.0.jar main.py
  660  deo 00Jyton.py 01JythonHello.py
  661  java -jar jython-standalone-2.7.0.jar 00Jyton.py
  662  java -jar jython-standalone-2.7.0.jar 01JythonHello.py
  663  java -jar jython-installer-2.7.0.jar
  664  jython
  665  deo kZshrc19
  667  deo ruby2MySQL.rb
  668  mkdir cppLight
  669  cd cppLight
  670  gcc test.c -l sqlite3
  671  deo test.c testCreatePlus.c
  672  deo testCreatePlus.c
  673  gcc testCreatePlus.c -l sqlite3
  674  mkdi goLite
  675  mkdir goLite
  677  cd go/
  678  go get github.com/mattn/go-sqlite3
  679  go install github.com/mattn/go-sqlite3
  681  cp -r dotFiles dotFiles-SqLight1
  682  mv dotFiles-SqLight1 /media/red/A5A1-FBC4/RED-ViM-MPI-gz
  683  deo weka.vim
  685  mv cppLight cppLite
  686  ls *.rb
  688  ./mini.rb
  689  mkdir RUBY
  690  deo template.rb
  691  deo profileIt.rb
  692  ruby -e 'puts $:'
  693  mv mini.rb RUBY
  694  ls RUBY
  695  deo
  697  cd torch
  698  deo prepTorch.vim
  699  cd RUBY
  700  deo mini.rb
  701  echo *
  702  cd jYthon
  703  deo 01JythonHello.py
  704  cp -r Jython protoJyton
  705  rm -r Jython
  706  deo 02JythonHello.py
  707  cd git/aTest/dotFiles/nVim/pdbA/jYthon
  708  deo helloIJ.java
  709  jython main.py
  714  cd cppLite
  715  h test.c
  716  deo test.c
  717  cd git/aTest/dotFiles/nVim/pdbA/mysql/cppLite
  718  gcc test.c -l sqlite3\n
  719  gcc -o testDB test.c -l sqlite3\n
  720  ./testDB
  721  gcc -o 1col 1column.c -l sqlite3\n
  724  deo geakSQligt.c
  725  cd git/aTest
  726  ls 4c/gruss
  727  cd 4c/gruss/HelloWorld
  729  cd 4c
  730  ls gruss
  731  ls gruss/HelloWorld
  732  ls gruss/HelloWorld/src
  733  ls gruss/HelloWorld/inc
  734  cd gruss/HelloWorld/inc
  735  deo hello.h
  738  deo mpipe.sh
  740  c\n
  741  exit
  744  dei g++
  745  deo g++
  748  deo Makefile src/hello.cpp src/main.cpp
  750  cd 4NeoCPP
  753  cd gruss/HelloWorld
  756  deo Makefile src/hello.cpp src/main.cpp 2014.txt 2014.inc
  757  cd ../../..
  758  cd 4NeoCPP/gruss/HelloWorld/bin
  762  deo Makefile src/hello.cpp src/main.cpp 2014.txt
  766  mkdir EX1
  774  deo ex1.c
  778  cd ../../
  780  cd EX1
  787  ./ex1
  790  deo bird.c
  793  make bird
  795  ./bird
  797  deo salary1.c
  798  make salary1
  800  ./salary1
  802  make sompleIf
  811  make simpleIf
  816  ./simpleIf
  818  ./choiseIf
  819  ./calc5e
  824  ./simon
  827  ./gradeArr
  829  ./addressVar
  830  deo ttt.c Makefile
  832  ./ttt
  833  ./strLengs
  835  ./strArr
  836  ./pointER
  837  ./point2dArr
  840  ./primeMaloc
  841  deo primeMaloc.c
  844  gcc -c sortString.c -o 1sort
  846  chmod +x 1sort
  850  make ex1
  851  make sortString
  853  ./1sort
  856  gcc -c globalVar361.c -o 1global
  857  chmod +x 1global
  858  ./1global
  859  ./globalVar361
  860  ./program98A
  861  ./program98A hallo
  862  ./program98A hallo Linux
  863  ./program98A hallo Ubuntu Linux
  864  ./program98A hallo Ubuntu Linux 16 04 2018
  865  ./charPrint423
  866  ./timeMashine578
  873  exa
  876  pwd
  879  cp -r ../gruss/HelloWorld .
  881  cd HelloWorld
  883  rm 2014.txt~
  886  deo src/hello.cpp src/main.cpp
  890  sd src
  891  cd src
  896  cd bin
  904  deo pointFunc.o
  905  ./pointFunc.o
  908  mv pointFunc.c pointFunc351Err.c
  909  mv sortString.c sortString339Err.c
  914  deo pipe.c
  918  ./npipe
  919  deo pipeThread.c
  921  ./a.out
  923  cp -r EX1 ../dotFiles/nVim/pdbA/cEX1
  927  cd dotFiles/nVim/pdbA
  929  ls mysql
  932  cd cYthon
  940  doe pythagor.pyx
  941  deo pythagor.pyx
  948  ./tri.so
  949  cython tri.pyx
  953  ./hello.so
  954  cython hello.pyx
  955  deo hello.pyx
  956  history
  959  h
  960  h 100
  962  cd pythagor
  965  deo testPythagor.py
  971  mkdir MAKE
  972  cd MAKE
  975  sudo su
  980  cd ~/git/aTest/dotFiles/nVim/pdbA/RUBY
  982  deo helloFox.rb mini.rb
  986  cd pdbA/cEX1
  988  rm *.o
  991  rm 1global 1sort
  994  cd ../git
  997  mkdir protoTorch
  998  git clone --recursive https://github.com/pytorch/pytorch
  999  deo minit.vim DEO3.vim
 1002  cp -r nVim mix90DEO3-C-hardWay
 1003  cp -r mix90DEO3-C-hardWay /media/red/A5A1-FBC4/RED-ViM-MPI-gz
 1011  ls goLite
 1012  ls cppLite
 1015  du RET
 1016  du -h
 1023  deo swapAliceBop.c
 1027  cd cEX1
 1030  ./swapAliceBop
 1032  ./2clockMe
 1035  ./5clockMe
 1036  ./4clockMe
 1037  ./matrixMult
 1038  ./matrix2Mult
 1040  ./matrix3Mult
 1041  deo simple1.cpp
 1042  ./simple1
 1044  ./simple2IO
 1046  g++ -fopenmp -o omp1.ex omp1.cpp
 1049  export OMP NUM THREADS=2
 1050  time ./omp1.ex
 1051  ./omp1.ex
 1053  g++ -fopenmp -o omp2.ex omp2.cpp
 1054  time ./omp2.ex
 1055  mpic++ -o mpi1.ex mpi1.cpp
 1056  ./ritaStrkt
 1057  ./demo1
 1061  cd ~/git/protoGoPyCpp/cpp-learning-master
 1064  rm cpp_calendar
 1067  ./cpp_calendar
 1069  deo semaphor.cpp
 1070  komodo
 1075  cd '/media/red/A5A1-FBC4/2019PyLink/CPP-Link/CPP-master/Lesson9/Observer'
 1078  deo MyClock.cpp
 1080  deo DigitalClock.cpp
 1082  ./DigitalClock.
 1088  cd Decorator
 1090  deo Window.cpp Window.h
 1094  deo Decorator*
 1095  cd '/home/red/git/protoJyton/weka-3-8-3'
 1097  java -jar weka.jar
 1098  orange
 1099  python3 -m Orange.canvas
 1104  cd mysql
 1108  cp -r cppLite DODO10
 1112  cp ../../cEX1/Makefile .
 1114  deo Makefile test.c testCreatePlus.c
 1118  cd mysql/DODO10
 1130  rm geakSQligt.c
 1133  rm test.db
 1136  ./openDodo10
 1148  file openDodo10
 1149  nm openDodo10
 1150  ldd openDodo10
 1152  cd ~/git/aTest/dotFiles/nVim/pdbA/MAKE
 1155  deo makeSameln
 1157  rm testDB
 1160  ./select2Dodo10
 1164  cp python2TestLight.py DODO10
 1165  cp ruby1SQLight.rb DODO10
 1166  deo php*
 1169  cd goLite
 1171  cp main.go ../DODO10
 1183  deo python2TestLight.py
 1187  deo main.go
 1189  cp -r nVim mix91DEO3-C-SQLite-Py-Ru-Go
 1191  ./a
 1198  rm hello.o hello
 1202  ./helloEX
 1204  ./hello1EX
 1209  ./h1EX
 1210  ./h2EX
 1212  cd helloMake
 1217  rm h1EX h2EX
 1218  s
 1221  make hello
 1223  ./hello
 1226  make VOTE16
 1227  make preser
 1228  deo Makefile
 1234  make
 1235  make run
 1240  make all
 1242  make clean
 1247  cd ../..
 1250  ls -la
 1251  ls -laC
 1252  ls -lC
 1253  l
 1254  l -C
 1256  exa -lT
 1258  du -sh .
 1259  du -mh .
 1261  du -c .
 1264  du -h .
 1265  du --time
 1266  du -hcd
 1267  du -hcd 3
 1268  du -hcd 2
 1269  du -hcd 1
 1271  deo gitBOX
 1272  cd ~/
 1277  cp .gitconfig git/aTest/dotFiles/nVim/kGitconfig
 1278  cp .gitignore git/aTest/dotFiles/nVim/kGitignore
 1283  cp dotFiles/nVim/kGitignore .gitignore
 1284  vi .gitignore .gitconfig
 1290  mkdir bTest
 1291  cd bTest
 1293  git init
 1295  cp ../aTest/dotFiles/nVim/kGitignore .gitignore
 1298  cp -r ../aTest/dotFiles/nVim/pdbA/mysql/DODO DODO
 1299  cp -r ../aTest/dotFiles/nVim/pdbA/mysql/DODO10 .
 1303  ls DODO10
 1304  ls DODO10/helloMake
 1305  cd DODO10
 1307  rm -r helloMake
 1310  la
 1316  cd ..
 1317  cd -
 1320  git add .
 1321  git commit -a
 1324  :qa
 1326  cd git/bTest
 1328  git status
 1329  git log
 1330  g log --graph
 1331  c
 1332  ls
 1333  mkdir kDot
