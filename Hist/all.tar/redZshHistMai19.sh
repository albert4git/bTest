    1  vi .zshrc
    2  cd .oh-my-zsh
    3  cd themes
    4  ni .zsh-theme
    5  mkdir zSH
    6  ni oh-my-zsh.info
    7  cd .oh-my-zsh/plugins
    8  echo ("hello word")
    9  echo ("hello word");
   10  echo "hello word"
   11  echo "hello word \n"
   12  echo "hell word \n"
   13  echo "oh my plugin \n \n"
   14  echo "tahshe"
   15  cd git/aTest/
   16  echo "tashe"
   17  battery_level_gauge
   18  man cp
   19  top 
   20  hsi man
   21  t
   22  ccat oh-my-zsh.vim
   23  nvim ninitOkt18.vim
   24  ni antigenPlusOMZ.conf
   25  cd ../nVim
   26  ni ninitOkt18.vim
   27  nu completZSH.vim
   28  ni completZSH.vim
   29  fzf -g cuku$
   30  fzf -q cuku$
   31  fzf -q vim$
   32  git clone https://github.com/zdharma/fast-syntax-highlighting.git \\n  ~/.oh-my-zsh/custom/plugins/fast-syntax-highlighting
   33  echo "epafania"
   34  echo "epafania \n"
   35  while {(echo "grep")}\n
   36  curl -sL --proto-redir -all,https https://raw.githubusercontent.com/zplug/installer/master/installer.zsh | zsh
   37  mv .zshrc zshrcOMZ
   38  lear
   39  ni zshrcOMZ
   40  echo "koshkina"
   41  nvim .zshrc
   42  mkdir fiSH
   43  ni config01.fish
   44  nvim config01.fish
   45  top -v
   46  ni .zsh_history
   47  cd git/aTest/dotFiles
   48  cd pyLabGitPdbPythonMode27
   49  dirs -v:
   50  cd git/aTest/dataPull
   51  cd ../git
   52  /g/a/
   53  cd dotFiles/zSH
   54  git add johanZshrc
   55  git add 0*
   56  git commit --all
   57  d
   58  hsi
   59  r
   60  r dir
   61  dirs
   62  r pw
   63  print -l bakBukLocal/**/*
   64  lsa bakBukLocal/**/*
   65  print -l bakBukLocal/**/*(/)
   66  ls -l bakBukLocal/**/*(/)
   67  lsl dotFiles/**/*(Lk+2)
   68  lsl dotFiles/**/*(Lk+9)
   69  cp -r .zplug zplug0402
   70  ni .zshrc
   71  lsl dotFiles/**/*(Lk+99)
   72  lsl **/*(Lk+99)
   73  ls **/*(Lk+99)
   74  ls -l bakBukLocal/**/*
   75  ls -l **/*
   76  ls -l **/*.md
   77  ls -l *
   78  ls -l **
   79  cd ~/git/aTest/dotFiles
   80  cd ~/
   81  tree zsh_demo
   82  tree -su zsh_demo
   83  tree -s zsh_demo
   84  tree -tsu zsh_demo
   85  tree -tsu zsh_demo/**(/)
   86  tree -tsu zsh_demo/*
   87  tree -tsu zsh_demo/**/*
   88  tree -tsu zsh_demo/**
   89  ls zsh_demo/*
   90  ls zsh_demo/**
   91  git clone https://github.com/bhilburn/powerlevel9k.git ~/powerlevel9k
   92  ls -l zsh_demo/**/*(L0)
   93  ls -l zsh_demo/**/*(om[1,3])
   94  ls -l zsh_demo/**/*.
   95  ls -l zsh_demo/**/*(Lm-2)
   96  print -l zsh_demo/*/*(e:'[[ ! -e $REPLY/malta ]]':)
   97  print -l zsh_demo/*/*(e:'[[  -e $REPLY/malta ]]':)
   98  print -l zsh_demo/**/*(e:'[[  -e $REPLY/malta ]]':)
   99  print -l zsh_demo/**/*.txt(e:'[[  -e $REPLY/malta ]]':)
  100  print -l zsh_demo/**/*.(e:'[[  -e $REPLY/malta ]]':)
  101  ls print -l zsh_demo/**/*.txt(e:'[[  -e $REPLY/malta ]]':)
  102  ls zsh_demo
  103  ls -l zsh_demo/**/*.txt(e:'[[  -e $REPLY/malta ]]':)
  104  ls -l zsh_demo/**/*(e:'[[  -e $REPLY/malta ]]':)
  105  ls zsh_demo/**/*
  106  ls zsh_demo/**/*.txt
  107  ls print -l zsh_demo/**/*(e:'[[  -e $REPLY/malta ]]':)
  108  print -l zsh_demo/data/europe/poland/*.txt(:t)
  109  print -l zsh_demo/data/europe/poland/*.txt(:t:r)
  110  print -l zsh_demo/data/europe/poland/*.txt(:e)
  111  print -l zsh_demo/data/europe/poland/*.txt(:h)
  112  print -l zsh_demo/data/europe/poland/*.txt(:h:h)
  113  print -l zsh_demo/data/europe/poland/*.txt(:h:h:h)
  114  print -l zsh_demo/data/europe/poland/*.txt(:h:h:h:h)
  115  du -sk .
  116  ./**
  117  du -sk ./**
  118  du -sk ./**(/)
  119  du -sk ./**/*(/)
  120  du -sk ./**/**(/)
  121  vi
  122  ni
  123  dirs -p
  124  cd ~1
  125  cd ~2
  126  cd ~+1
  127  cd ~/Documents/LanCore
  128  cd ~+2
  129  ls -d **
  130  ls -d **(/)
  131  ls -d ./**(/)
  132  ls -d ./**/*(/)
  133  ls -d ./**/*
  134  my_file=(zsh_demo/data/europe/poland/*.txt([1]))
  135  print -l $my_file
  136  print -l $my_file(:h)
  137  for file in zsh_demo/data/**/income.txt ; do\n output_dir=${file:h:s/data/calculations/}\n country=${output_dir:t}\n output_file="${output_dir}/${country}_max_income.txt"\n echo "The max salary is $RANDOM dollars" >| $output_file\ndone
  138  grep "" zsh_demo/calculations/**/*_max_income.txt
  139  echo
  140  ex
  141  echo ${my_variable:s/bc/BC/ \n}
  142  echo ${my_variable:s/bc/BC/}
  143  my_variable="path/abcd"
  144  echo ${my_variable:s_/_._}
  145  my_variable="aaa"
  146  echo ${my_variable:gs/a/A/}
  147  dirs -v
  148  cd ~/git/aTest/dotFiles/zSH/poligon
  149  # Let's say somebody gave you these updated files\n# and told you to replace the old ones\necho $RANDOM > zsh_demo/africa_malawi_population_2014.txt\necho $RANDOM > zsh_demo/asia_nepal_income_2014.txt\necho $RANDOM > zsh_demo/europe_malta_literacy_2014.txt\n
  150  echo $RANDOM >| zsh_demo/africa_malawi_population_2014.txt\n
  151  echo $RANDOM >| zsh_demo/asia_nepal_income_2014.txt\n
  152  echo $RANDOM >| zsh_demo/europe_malta_literacy_2014.txt\n
  153  for file in zsh_demo/*.txt; do\n file_info=(${(s._.)file:t})\n continent=$file_info[1]\n country=$file_info[2]\n data=$file_info[3]\n\n mv -f $file zsh_demo/data/${continent}/${country}/${data}.txt\ndone
  154  grep "" zsh_demo/**/*(.mm-5)
  155  grep "" zsh_demo/**/*(.mm-5) | fzf
  156  echo $file
  157  my_array=(a b c d)
  158  echo ${(j.-.)my_array}
  159  ls -h
  160  echo ${(j_._)my_array}
  161  ls zsh_demo/data/asia/laos/population.txt
  162  ls -l zsh_demo/data/asia/laos/population.txt
  163  echo a b c
  164  print -1 a b c
  165  print -l print -l a b c
  166  print -l a b c
  167  ls ~/git/aTest/dotFiles
  168  ls -l ~/git/aTest/dotFiles
  169  ls zsh_demo/data/europe/malta/literacy.txt
  170  awk '$1 > 3' zsh_demo/data/europe/malta/literacy.txt
  171  cp zshUsersZshAutosugestionBinKey.vim tZshUsersZshAutosugestionBinKey.vim
  172  mv zwishenCode.vim tZwishenCode.vim
  173  rm zshUsersZshAutosugestionBinKey.vim
  174  04zshrc
  175  ni 04zshrc
  176  mv zplugReadMe.md tZplugReadMe.md
  177  ni zshrcFeb2019
  178  cd zSH
  179  cd ../zSH
  180  
  181  cd git/4exa
  182  cd aTest
  183  cd dotFiles
  184  cd nVim
  185  his
  186  echo "krasnopol"
  187  lss
  188  cd /home/red/git/aTest/~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  189  bash
  190  exa
  191  ll
  192  lsc
  193  ls plugins
  194  tmux kill-session
  195  mux start kBank21
  196  cd DODO10/
  197  cd ~/.config/nvim/plugged/
  198  cd /home/red/git/bTest
  199  cd ~/.config/nvim/
  200  de DODO10/cSwitch.c
  201  cd ~/.zplug/repos/robbyrussell/oh-my-zsh/
  202  cd ~/.zplug/repos/zsh-users/
  203  de kDot/k5DEO.vim
  204  cd .config/nvim/spell
  205  curl -O "http://ftp.vim.org/pub/vim/runtime/spell/en.utf-8.spl\nls\nla
  206  curl -O "http://ftp.vim.org/pub/vim/runtime/spell/en.utf-8.spl .
  207  dict -D
  208  exal -l
  209  fc
  210  cp ~/Music/*.spl
  211  cp ~/Music/*.spl .
  212  cp ~/Music/*.sug .
  213  vi de.utf-8.sug
  214  vi de.utf-8.spl
  215  exa -l
  216  ls -lh
  217  cd ~/.vim/spell
  218  deo kMinit.vim k5DEO.vim
  219  cd ~/Videos/Lex/asccalc-master
  220  cd simple-lexical-analyzer-master
  221  flex -o file.c file.l
  222  ^[[200~function! ExampleFunction(arg1, arg2)
  223  python << endPython
  224  tmux ls
  225  tmux a -t bank21B
  226  cd DODO10
  227  cd ../kDot
  228  cd BASH
  229  de bCheat1BASH.sh b2Bash.sh bOooBash.sh
  230  cd ~/.local/share/nvim/site/
  231  ls autoload
  232  cd spell
  233  git show-branch
  234  git reflog
  235  tig reflog
  236  hh | grep tig
  237  ps aux | grep videos
  238  deo kMinit.vim
  239  cd ~/git/aTest/dotFiles/nVim
  240  de nMakeInstallVim82.vim nMake.vim
  241  v
  242  ls OLD
  243  lsl
  244  xx
  245  git mv BASH/ LabBASH
  246  git mkdir LabVim
  247  mkdir LabVimL
  248  mkdir LabPy
  249  mkdir LabSciPy
  250  mkdir LabC
  251  mkdir LabCPP
  252  mkdir LabPuDB
  253  git mv 0vimL0scrap.vim LabVimL
  254  mkdir LabGit
  255  ls myPlug
  256  git mv myPlug/ LabVimPlug
  257  git mv TIPS/ LabTIPS
  258  git mv inkWim/ LabInkWim
  259  cd DICT
  260  cp -r ~/.config/nvim/spell .
  261  ls spell
  262  mv spell deoSpell
  263  cat 4GitRun.sh
  264  mkdir LabGO
  265  mkdir LabJAVA
  266  ls P2Patch
  267  ls PPatch
  268  ls RubySolar
  269  git mv 4GitRun.sh LabGit
  270  cat mopOptic.vim
  271  q
  272  git add
  273  cat zbuf.vim
  274  git log --oneline
  275  cd LabGit
  276  de 4GitRun.sh
  277  git --shortstat
  278  git diff --shortstat
  279  git diff --shortstat HEAD~2
  280  git diff --stat HEAD~2
  281  git diff --stat HEAD^
  282  git diff --stat HEAD~1
  283  git log --shortstat
  284  git diff --stat HEAD~5
  285  git diff --stat HEAD~5 k5DEO.vim
  286  git diff --stat HEAD~5 *.txt
  287  gst
  288  tig status
  289  kdeo kMinit.vim
  290  cd git/aTest/dotFiles/nVim
  291  cd pdbA
  292  cp 50calculator.py ~/git/bTest/kDot/LabPuDB
  293  cp absMin.py ~/git/bTest/kDot/LabPuDB
  294  mv 50calculator.py 50calc.py
  295  de 50calc.py
  296  cp 50calc.py 50calculator.py
  297  cd Videos/Lex/asccalc-master
  298  ./asccalc
  299  kdeo kMinit.vim kBank21.yml
  300  de fibonacci.py
  301  python3 fibonacci_doctest.py
  302  de fibonacci*
  303  python3 fibonacci_unittest.py
  304  python3 fibonacci_unittest2.py
  305  python3 upperCase.py
  306  cd LabC
  307  ls *.c
  308  ls cEX1
  309  cd cEX1
  310  de 5clockMe.c clac5e.c
  311  cp ../../DODO10/cStrgCp.c .
  312  de cStrgCp.c
  313  cd ../LabPuDB
  314  mv 50* ../LabPy
  315  cat absMin.py
  316  mv absMin.py ../LabPy
  317  mkdir fib* PyFib
  318  mv fib* PyFib
  319  cat upperCase.py
  320  cat absMax.py
  321  cat abs.py
  322  de abs.py
  323  mv upperCase.py upperCaseTest.py
  324  cd LabPuDB
  325  de primes.py test_primes.py
  326  python3 run_primes.py
  327  ls PyFib
  328  mkdir PrimesLogAndConf
  329  cp primes.py Primes
  330  cp run_primes.py PrimesLogAndConf
  331  cp test_primes.py PrimesLogAndConf
  332  mv PrimesLogAndConf LogAndConfPrimes
  333  de Makefile
  334  ls Primes
  335  rm -r Primes
  336  cp primes.py LogAndConfPrimes
  337  ccat check1_primes.log
  338  cd LogAndConfPrimes
  339  ccar D:\\Logs\\PyLogs\\20190417000733.log
  340  ccat D:\\Logs\\PyLogs\\20190417000733.log
  341  rm *000*
  342  rm *00*
  343  ccat InPlayLog20190417011823.log
  344  ccat InPlayLog20190417023759.log
  345  ccat InPlayLog20190417023029.log
  346  ccat InPlayLog20190417024144.log
  347  ccat InPlayLog20190417024504.log
  348  ccat InPlayLog20190417024725.log
  349  ccat InPlayLog20190417025310.log
  350  ccat InPlayLog20190417030424.log
  351  ccat InPlayLog20190417031100.log
  352  de InPlayLog20190417.log
  353  tail InPlayLog20190417.log
  354  ccat test_primes.py
  355  python test_primes.py
  356  python test_primes.py | ccat
  357  py test_primes.py
  358  ca InPlayLog20190417.log
  359  watch "tail -f | ccat" InPlayLog20190417.log
  360  watch "tail -f" InPlayLog20190417.log
  361  watch "less +F" InPlayLog20190417.log
  362  less +F InPlayLog20190417.log
  363  ccat test_primes.py | less -R
  364  ccat InPlayLog20190417.log | less +F
  365  watch "ccat" InPlayLog20190417.log
  366  ccat InPlayLog20190417.log
  367  cd ../LabPy
  368  python lena1.py
  369  python3 lena1.py
  370  cd -2
  371  ls p*
  372  rm *0.log
  373  rm *2.log
  374  rm *4.log
  375  rm *5.log
  376  rm *6.log
  377  rm *8.log
  378  rm *9.log
  379  rm *3.log
  380  cp -r LogAndConfPrimes PuLogAndConfPrimes
  381  python -m pudb run_primes.py
  382  ccat InPlayLog20190418.log
  383  python -m pudb primes.py
  384  python -m pudb primes.py run_primes.py
  385  python -m pudb run_primes.py primes.py
  386  cd pudb
  387  ccat pudb.cfg
  388  ccat saved-breakpoints-2.7
  389  mkdir PhiPoly
  390  cd PhiPoly
  391  de
  392  de run_PhiPoly.py PhiPoly.py
  393  cd ../PhiPoly
  394  python run_PhiPoly.py
  395  cd ../PuLogAndConfPrimes
  396  python run_primes.py
  397  n
  398  pudb run_primes.py
  399  cd git/bTest/kDot/LabPuDB
  400  de run_primes.py
  401  de primes.py run_primes.py
  402  less +F InPlayLog20190418.log
  403  cd .config/nvim/plugged
  404  ls less.vim
  405  de less.vim/README.mkd
  406  cd git/bTest/kDot/LabPuDB/PuLogAndConfPrimes
  407  $VIMRUNTIME/macros/less.sh
  408  ./home/red/82vim/share/vim/vim81/macros/less.sh
  409  cd /home/red/82vim/share/vim/vim81/macros/
  410  ch +x less.sh
  411  chmod +x less.sh
  412  ./less.sh
  413  ./less.sh README.txt
  414  ./home/red/82vim/share/vim/vim81/macros/less.sh InPlayLog20190417.log\n
  415  cp /home/red/82vim/share/vim/vim81/macros/less.sh .\n
  416  ./less.sh InPlayLog20190418.log
  417  ./less.sh +F InPlayLog20190418.log
  418  watch ccat InPlayLog20190417.log
  419  ca InPlayLog20190418.log
  420  de InPlayLog20190418.log
  421  cd less.vim
  422  de less.vim
  423  deless InPlayLog20190418.log
  424  ps aux | ./txts -n ps
  425  ps aux
  426  top
  427  top | ./txts -n ps
  428  top | ./txts -n ifconfig
  429  echo "A Foo and a Bar" | ./txts -r Foo -r Bar
  430  ls txtstyle
  431  ./txts -h
  432  ./txts --version
  433  deo README.md
  434  cd ~/Music/TxtStyle-master
  435  ./txts -n first example.log
  436  ./txts -n example example.log
  437  ./txts -n ps example.log
  438  ./txts -n tail example.log
  439  ./txts -n java example.log
  440  ./txts -n exm example.log
  441  ./txts -n ifconfig example.log
  442  ./txts -n calendar example.log
  443  sudo python2 setup.py install
  444  txts -n java example.log
  445  txts -n alf example.log
  446  txts -n example example.log
  447  tail -f example.log | txts -n java
  448  tail -f example.log | txts -n example
  449  tail -f InPlayLog20190419.log | txts -n alf
  450  less +F InPlayLog20190419.log | txts -n ps
  451  less +f *.log | txts -n ps
  452  tail -f InPlayLog20190419.log | txts -n example
  453  cd ../colortail-master
  454  ./configure.in
  455  colortail InPlayLog20190419.log
  456  tail InPlayLog20190419.log
  457  colortail -k *.log
  458  colortail -k InPlayLog20190419.log
  459  tail InPlayLog20190419.log | txts -n calendar
  460  tail -f InPlayLog20190419.log | txts -n calendar
  461  tail -f InPlayLog20190419.log | txts -n ps
  462  deless InPlayLog20190419.log | txts -n calendar
  463  cat InPlayLog20190419.log | txts -n calendar
  464  tail -f InPlayLog20190419.log | ccze
  465  tail -f -n 15 InPlayLog20190419.log | ccze
  466  less +F InPlayLog20190419.log | ccze
  467  ccze -m ansi < InPlayLog20190419.log | deless
  468  ccze -m ansi < InPlayLog20190419.log | less
  469  ccze -m ansi < InPlayLog20190419.log | less -r
  470  vim
  471  livepython run_primes.py
  472  deless InPlayLog20190419.log
  473  rm kLess3Y.vim
  474  rm *.jpg
  475  rm *.png
  476  cd kDot/LabPy
  477  rm lena*
  478  git add .
  479  deo angularJS.vim
  480  ncdu | ccze
  481  du | ccze
  482  du . | ccze
  483  du
  484  du -h
  485  du -h | ccze
  486  ls WIMRC
  487  de kZshrc19.sh WIMRC/wimrc-tech-php.vim
  488  wi1
  489  ls ../
  490  cd ~/git/aTest/dotFiles/
  491  ls inkWim
  492  cd inkWim
  493  de xvim-*
  494  cd ~/.vim/
  495  ls plugin
  496  ls plugged
  497  mkdir bundle
  498  ls bundle
  499  wi2
  500  wi3
  501  de demian-wimrc.vim wim-nakamura.vim wimrc-erik.vim
  502  wi4
  503  wi5
  504  cd ~/git/bTest/kDot
  505  ncdu
  506  cd ~/.config
  507  ls Zeal
  508  ls livepython
  509  de livepython/Preferences
  510  cd /usr/local/lib/node_modules
  511  ls create-react-app
  512  ls create-react-app/node_modules
  513  ls expo-cli
  514  ls expo-cli/node_modules
  515  ls pkg
  516  ls pkg/node_modules
  517  ls tern
  518  ls tern/node_modules
  519  ls yarn/
  520  mkdir LabJS
  521  cd LabJS
  522  de qStart.js
  523  node qStart.js
  524  cd ../../../jsReact
  525  ls hello-world
  526  ls 2run
  527  ls 2run/AwesomeProject
  528  de src/App.js
  529  ls 2run/AwesomeProject/
  530  cd 2run/AwesomeProject/
  531  cd ....
  532  ....
  533  cd bTest/kDot/LabPuDB
  534  cd PuLogAndConfPrimes
  535  tail -f InPlayLog20190419.log | perl -pe 's/DEBUG/\e[1;31;43m$&\e[0m/g'
  536  ptail
  537  tail -f InPlayLog20190419.log | perl -pe 's/DEBUG/\e[1;31;43m$&\e[0m/g' | perl -pe 's/INFO/\e[1;30;43m$&\e[0m/g'\n
  538  tail -f InPlayLog20190419.log | perl -pe 's/INFO/\e[1;30;43m$&\e[0m/g'\n
  539  ptail= 'tail -f InPlayLog20190419.log | grey-grep ".*DEBUG*|$" | cyan-grep "INFO|$" | yellow-grep "WARN|$" | red-grep "[ERROR].*|[FATAL].*|$" | green-grep "***|$"'\n
  540  tail -f InPlayLog20190419.log | grey-grep ".*DEBUG*|$" | cyan-grep "INFO|$" | yellow-grep "WARN|$" | red-grep "[ERROR].*|[FATAL].*|$" | green-grep "***|$"\n
  541  de ~/.txts.conf
  542  tail -f example.log | txts -n cy1
  543  tail -f example.log | grep --color=always -E "$|REGEXP"
  544  tail -f -n 50 /var/log/apache2/error.log | color -l [error\]","\[notice\]"\ntail -f -n 50 example.log | color -l "\[error\]","\[notice\]"\ntail -f -n 50 example.log | color -l "\[error\]","\[notice\]"\nclear
  545  tail -f -n 50 example.log | color -l "\[error\]","\[notice\]"
  546  python -m cProfile run_primes.py
  547  python -m cProfile -o proff.cprof run_primes.py
  548  ccat proff.cprof
  549  pyprof2calltree -k -i proff.cprof
  550  python -m cProfile -s cumtime run_primes.py
  551  de ptest.py
  552  python -m cProfile ptest.py
  553  python -m cProfile -o output.txt ptest.py
  554  ipython
  555  de Proff.py
  556  python Proff.py
  557  new fact.py
  558  de fact.py
  559  python -m cProfile fact.py
  560  mv fact.py Fact.py
  561  python -m cProfile Fact.py
  562  de Proff2.py
  563  py Proff2.py
  564  py3 Proff2.py
  565  py3 Proff2.py | cat >>| op2.log
  566  py Proff2.py | cat >>| op2.log
  567  ca op2.log
  568  de op2.log
  569  py3 Proff3.py
  570  ca run_primes.py
  571  ca test_primes.py
  572  cat Proff.py
  573  hh | vim -
  574  zeal
  575  ranger
  576  cd calculator-master
  577  npm c
  578  npm
  579  npm -h
  580  npm help
  581  cd Realtime-calendar-master
  582  cd client
  583  npm install -g bower
  584  cd git/jsReact/digital-clock-js-master
  585  cd ../react-clockwall-master
  586  cd ../clock-component-master
  587  cd polymer
  588  bower install
  589  node server.js
  590  cd ~/snap
  591  snap install vidcutter
  592  cd '/media/red/pink/Bald'
  593  cd /media/red/pink
  594  ls -l
  595  ffmpeg -i concat:"*.mp4" output.mp4
  596  ls -d $PWD
  597  ls -d -1 $PWD
  598  l | cat >>| in.txt
  599  ffmpeg -f concat -i in.txt output.mp4
  600  ffmpeg -i concat:"1.mp4|2.mp4" output12.mp4
  601  ffmpeg -i concat:"5.mp4|6.mp4" o56.mp4
  602  ffmpeg -i concat:"4.mp4|6.mp4" o56.mp4
  603  ffmpeg -i concat:"4.mp4|6.mp4" o46.mp4
  604  ffmpeg -i concat:"o12.mp4|46.mp4" oo1246.mp4
  605  ffmpeg -i concat:"o12.mp4|o46.mp4" oo1246.mp4
  606  cd ~/Pictures
  607  cd Bald
  608  cd ~/git/
  609  vi Install-Linux-tar.txt
  610  cd /media/red/A5A1-FBC4/sK1
  611  cd Pictures/Bald
  612  deo in.txt
  613  ffmpeg -f concat -safe 0 -i in.txt -c copy out.mp4\n
  614  de in.txt
  615  ffmpeg -f concat -safe 0 -i in.txt -c copy cout.mp4\n
  616  cd git/android-studio
  618  cd ~/git/jsReact
  619  cd digital-clock-js-master
  620  cp -r digital-clock-js-master digital-clock-js
  621  cd digital-clock-js
  622  de app.js
  623  cp -r react-clockwall-master react-clockwall
  624  cd react-clockwall
  625  { id: 'clock3', town: 'Paris', timezone: 'Europe/Paris', locale: 'fr' },
  626  de index.html
  627  de src/Index.js
  628  cd ../4run
  629  cd js-clock-master
  630  ls app
  631  ls app/css
  632  cat react-native-motivation-app-master
  633  cat react-native-motivation-app-master/README.md
  634  cd
  635  ls express-mysql-example-master
  636  cd express-mysql-example-master
  637  npm app.js
  638  hh | grep npm
  639  mpm run
  640  ls node_modules
  641  ls desktop-clock-master
  642  cd desktop-clock-master
  643  py clock.py
  644  py3 clock.py
  645  caut requirements.txt
  646  cat requirements.txt
  647  ls clock
  648  de clock.py
  649  cd Linux-Terminal-Clock-master
  650  gcc -o terminal_clock terminal_clock.c\n
  651  ./terminal_clock
  652  ./terminal_clock -C cyan
  653  de terminal_clock.c
  654  cd ../opengl-clock-master
  655  chmod +x compile.sh
  656  cat compile.sh
  657  ./compile.sh
  658  gcc -o clo clock.cpp\n
  659  gcc -L/usr/lib -o clo clock.cpp -lglut -lGL -lGLU
  660  cd bash-pro-master
  661  mv .bash_profile bash_pro.sh
  662  de bash_pro.sh
  663  sudo adduser $USER kvm
  664  cd git/jsReact/
  665  cd 4run
  666  cd local-sqlite-example
  667  npm run
  668  npm install react-clock
  669  cd react-native-motivation-app-master/
  670  mpm run website
  671  npm run playlist
  672  npm run website
  673  ls website
  674  cd js-budget-setup-master
  675  npm install cli-table
  676  mkdir POCsqlite
  677  cd POCsqlite
  678  git clone https://github.com/romwaldtff/NodeJS-REST-API-SQLite.git
  679  cd NodeJS-REST-API-SQLite
  680  node index.js
  681  kdeo kMinit.vim k5DEO.vim
  682  mkdir CHEATSH
  683  cd CHEATSH
  684  curl cheat.sh/tar
  685  curl cht.sh/curl
  686  curl cheat.sh/tar | cat >>| CHEET.vim
  687  cat CHEET.vim
  688  curl cheat.sh/rsync | cat >>| CHEET.vim
  689  curl cheat.sh/curl | cat >>| CHEET.vim
  690  curl cheat.sh/vim | cat >>| CHEET.vim
  691  curl cheat.sh/find | cat >>| CHEET.vim
  692  curl cheat.sh/awk | cat >>| CHEET.vim
  693  curl cheat.sh/gzip | cat >>| CHEET.vim
  694  curl cheat.sh/crontab | cat >>| CHEET.vim
  695  curl cheat.sh/ps | cat >>| CHEET.vim
  696  curl cheat.sh/df | cat >>| CHEET.vim
  697  curl cheat.sh/tail | cat >>| CHEET.vim
  698  curl cheat.sh/apt | cat >>| CHEET.vim
  699  curl cheat.sh/apt-get | cat >>| CHEET.vim
  700  curl cheat.sh/wget | cat >>| CHEET.vim
  701  ccat CHEET.vim
  702  curl cheat.sh/apt-get
  703  curl cheat.sh/apt
  704  curl cheat.sh/vim
  705  curl cheat.sh/find
  706  curl cheat.sh/grep
  707  curl cheat.sh/exa
  708  curl cheat.sh/df
  709  curl cheat.sh/mv
  710  h
  711  curl cheat.sh/rsync
  712  curl cheat.sh/wget
  713  curl cheat.sh/git
  714  curl cheat.sh/npm
  715  curl cheat.sh/dict
  716  curl cheat.sh/sed
  717  curl cheat.sh/python/lambda
  718  curl cheat.sh/python/~io
  719  curl cheat.sh/python/:learn
  720  curl cheat.sh/zsh
  721  curl cheat.sh/bash
  722  curl cheat.sh/go
  723  curl cheat.sh/go/:learn
  724  curl cheat.sh/cpp
  725  curl cheat.sh/cpp/:learn
  726  curl cheat.sh/c/:learn
  727  curl cheat.sh/c/
  728  curl cheat.sh/perl
  729  curl cheat.sh/perl/:learn
  730  curl cheat.sh/php/:learn
  731  curl cheat.sh/mysql/:learn
  732  curl cheat.sh/mysql/
  733  curl cheat.sh/sqlite/
  734  curl cheat.sh/sqlite3/
  735  curl cheat.sh/gcc
  736  curl cheat.sh/locate
  737  curl cheat.sh/android
  738  curl cheat.sh/java/:learn
  739  curl cheat.sh/java/:learn \n// Single-line comments start with //\n\n/*\nMulti-line comments look like this.\n*/\n\n/**\n * JavaDoc comments look like this. Used to describe the Class or various\n * attributes of a Class.\n * Main attributes:\n *\n * @author         Name (and contact information such as email) of author(s).\n * @version     Current version of the program.\n * @since        When this part of the program was first added.\n * @param         For describing the different parameters for a method.\n * @return        For describing what the method returns.\n * @deprecated  For showing the code is outdated or shouldn't be used.\n * @see         Links to another part of documentation.\n*/\n\n// Import ArrayList class inside of the java.util package\nimport java.util.ArrayList;\n// Import all classes inside of java.security package\nimport java.security.*;\n\npublic class LearnJava {\n\n    // In order to run a java program, it must have a main method as an entry\n    // point.\n    public static void main(String[] args) {\n\n    ///////////////////////////////////////\n    // Input/Output\n    ///////////////////////////////////////\n\n        /*\n        * Output\n        */\n\n        // Use System.out.println() to print lines.\n        System.out.println("Hello World!");\n        System.out.println(\n            "Integer: " + 10 +\n            " Double: " + 3.14 +\n            " Boolean: " + true);\n\n        // To print without a newline, use System.out.print().\n        System.out.print("Hello ");\n        System.out.print("World");\n\n        // Use System.out.printf() for easy formatted printing.\n        System.out.printf("pi = %.5f", Math.PI); // => pi = 3.14159\n\n        /*\n         * Input\n         */\n\n        // use Scanner to read input\n        // must import java.util.Scanner;\n        Scanner scanner = new Scanner(System.in);\n\n        // read string input\n        String name = scanner.next();\n\n        // read byte input\n        byte numByte = scanner.nextByte();\n\n        // read int input\n        int numInt = scanner.nextInt();\n\n        // read long input\n        float numFloat = scanner.nextFloat();\n\n        // read double input\n        double numDouble = scanner.nextDouble();\n\n        // read boolean input\n        boolean bool = scanner.nextBoolean();\n\n        ///////////////////////////////////////\n        // Variables\n        ///////////////////////////////////////\n\n        /*\n        *  Variable Declaration\n        */\n        // Declare a variable using <type> <name>\n        int fooInt;\n        // Declare multiple variables of the same\n        // type <type> <name1>, <name2>, <name3>\n        int fooInt1, fooInt2, fooInt3;\n\n        /*\n        *  Variable Initialization\n        */\n\n        // Initialize a variable using <type> <name> = <val>\n        int barInt = 1;\n        // Initialize multiple variables of same type with same\n        // value <type> <name1>, <name2>, <name3>\n        // <name1> = <name2> = <name3> = <val>\n        int barInt1, barInt2, barInt3;\n        barInt1 = barInt2 = barInt3 = 1;\n\n        /*\n        *  Variable types\n        */\n        // Byte - 8-bit signed two's complement integer\n        // (-128 <= byte <= 127)\n        byte fooByte = 100;\n\n        // If you would like to interpret a byte as an unsigned integer\n        // then this simple operation can help\n        int unsignedIntLessThan256 = 0xff & fooByte;\n        // this contrasts a cast which can be negative.\n        int signedInt = (int) fooByte;\n\n        // Short - 16-bit signed two's complement integer\n        // (-32,768 <= short <= 32,767)\n        short fooShort = 10000;\n\n        // Integer - 32-bit signed two's complement integer\n        // (-2,147,483,648 <= int <= 2,147,483,647)\n        int bazInt = 1;\n\n        // Long - 64-bit signed two's complement integer\n        // (-9,223,372,036,854,775,808 <= long <= 9,223,372,036,854,775,807)\n        long fooLong = 100000L;\n        // L is used to denote that this variable value is of type Long;\n        // anything without is treated as integer by default.\n\n        // Note: byte, short, int and long are signed. They can have positive and negative values.\n        // There are no unsigned variants.\n        // char, however, is 16-bit unsigned.\n\n        // Float - Single-precision 32-bit IEEE 754 Floating Point\n        // 2^-149 <= float <= (2-2^-23) * 2^127\n        float fooFloat = 234.5f;\n        // f or F is used to denote that this variable value is of type float;\n        // otherwise it is treated as double.\n\n        // Double - Double-precision 64-bit IEEE 754 Floating Point\n        // 2^-1074 <= x <= (2-2^-52) * 2^1023\n        double fooDouble = 123.4;\n\n        // Boolean - true & false\n        boolean fooBoolean = true;\n        boolean barBoolean = false;\n\n        // Char - A single 16-bit Unicode character\n        char fooChar = 'A';\n\n        // final variables can't be reassigned,\n        final int HOURS_I_WORK_PER_WEEK = 9001;\n        // but they can be initialized later.\n        final double E;\n        E = 2.71828;\n\n        // BigInteger - Immutable arbitrary-precision integers\n        //\n        // BigInteger is a data type that allows programmers to manipulate\n        // integers longer than 64-bits. Integers are stored as an array of\n        // of bytes and are manipulated using functions built into BigInteger\n        //\n        // BigInteger can be initialized using an array of bytes or a string.\n        BigInteger fooBigInteger = new BigInteger(fooByteArray);\n\n        // BigDecimal - Immutable, arbitrary-precision signed decimal number\n        //\n        // A BigDecimal takes two parts: an arbitrary precision integer\n        // unscaled value and a 32-bit integer scale\n        //\n        // BigDecimal allows the programmer complete control over decimal\n        // rounding. It is recommended to use BigDecimal with currency values\n        // and where exact decimal precision is required.\n        //\n        // BigDecimal can be initialized with an int, long, double or String\n        // or by initializing the unscaled value (BigInteger) and scale (int).\n        BigDecimal fooBigDecimal = new BigDecimal(fooBigInteger, fooInt);\n\n        // Be wary of the constructor that takes a float or double as\n        // the inaccuracy of the float/double will be copied in BigDecimal.\n        // Prefer the String constructor when you need an exact value.\n        BigDecimal tenCents = new BigDecimal("0.1");\n\n        // Strings\n        String fooString = "My String Is Here!";\n\n        // \n is an escaped character that starts a new line\n        String barString = "Printing on a new line?\nNo Problem!";\n        // \t is an escaped character that adds a tab character\n        String bazString = "Do you want to add a tab?\tNo Problem!";\n        System.out.println(fooString);\n        System.out.println(barString);\n        System.out.println(bazString);\n\n        // String Building\n        // #1 - with plus operator\n        // That's the basic way to do it (optimized under the hood)\n        String plusConcatenated = "Strings can " + "be concatenated " + "via + operator.";\n        System.out.println(plusConcatenated);\n        // Output: Strings can be concatenated via + operator.\n\n        // #2 - with StringBuilder\n        // This way doesn't create any intermediate strings. It just stores the string pieces, and ties them together\n        // when toString() is called.\n        // Hint: This class is not thread safe. A thread-safe alternative (with some impact on performance) is StringBuffer.\n        StringBuilder builderConcatenated = new StringBuilder();\n        builderConcatenated.append("You ");\n        builderConcatenated.append("can use ");\n        builderConcatenated.append("the StringBuilder class.");\n        System.out.println(builderConcatenated.toString()); // only now is the string built\n        // Output: You can use the StringBuilder class.\n\n        // StringBuilder is efficient when the fully constructed String is not required until the end of some processing.\n        StringBuilder stringBuilder = new StringBuilder();\n        String inefficientString = "";\n        for (int i = 0 ; i < 10; i++) {\n            stringBuilder.append(i).append(" ");\n            inefficientString += i + " ";\n        }\n        System.out.println(inefficientString);\n        System.out.println(stringBuilder.toString());\n        // inefficientString requires a lot more work to produce, as it generates a String on every loop iteration.\n        // Simple concatenation with + is compiled to a StringBuilder and toString()\n        // Avoid string concatenation in loops.\n\n        // #3 - with String formatter\n        // Another alternative way to create strings. Fast and readable.\n        String.format("%s may prefer %s.", "Or you", "String.format()");\n        // Output: Or you may prefer String.format().\n\n        // Arrays\n        // The array size must be decided upon instantiation\n        // The following formats work for declaring an array\n        // <datatype>[] <var name> = new <datatype>[<array size>];\n        // <datatype> <var name>[] = new <datatype>[<array size>];\n        int[] intArray = new int[10];\n        String[] stringArray = new String[1];\n        boolean boolArray[] = new boolean[100];\n\n        // Another way to declare & initialize an array\n        int[] y = {9000, 1000, 1337};\n        String names[] = {"Bob", "John", "Fred", "Juan Pedro"};\n        boolean bools[] = {true, false, false};\n\n        // Indexing an array - Accessing an element\n        System.out.println("intArray @ 0: " + intArray[0]);\n\n        // Arrays are zero-indexed and mutable.\n        intArray[1] = 1;\n        System.out.println("intArray @ 1: " + intArray[1]); // => 1\n\n        // Other data types worth checking out\n        // ArrayLists - Like arrays except more functionality is offered, and\n        //              the size is mutable.\n        // LinkedLists - Implementation of doubly-linked list. All of the\n        //               operations perform as could be expected for a\n        //               doubly-linked list.\n        // Maps - A mapping of key Objects to value Objects. Map is\n        //        an interface and therefore cannot be instantiated.\n        //        The type of keys and values contained in a Map must\n        //        be specified upon instantiation of the implementing\n        //        class. Each key may map to only one corresponding value,\n        //        and each key may appear only once (no duplicates).\n        // HashMaps - This class uses a hashtable to implement the Map\n        //            interface. This allows the execution time of basic\n        //            operations, such as get and insert element, to remain\n        //            constant-amortized even for large sets.\n        // TreeMap - A Map that is sorted by its keys. Each modification \n        //           maintains the sorting defined by either a Comparator\n        //           supplied at instantiation, or comparisons of each Object\n        //           if they implement the Comparable interface.\n        //           Failure of keys to implement Comparable combined with failure to\n        //           supply a Comparator will throw ClassCastExceptions.\n        //           Insertion and removal operations take O(log(n)) time\n        //           so avoid using this data structure unless you are taking\n        //           advantage of the sorting.\n\n        ///////////////////////////////////////\n        // Operators\n        ///////////////////////////////////////\n        System.out.println("\n->Operators");\n\n        int i1 = 1, i2 = 2; // Shorthand for multiple declarations\n\n        // Arithmetic is straightforward\n        System.out.println("1+2 = " + (i1 + i2)); // => 3\n        System.out.println("2-1 = " + (i2 - i1)); // => 1\n        System.out.println("2*1 = " + (i2 * i1)); // => 2\n        System.out.println("1/2 = " + (i1 / i2)); // => 0 (int/int returns int)\n        System.out.println("1/2.0 = " + (i1 / (double)i2)); // => 0.5\n\n        // Modulo\n        System.out.println("11%3 = "+(11 % 3)); // => 2\n\n        // Comparison operators\n        System.out.println("3 == 2? " + (3 == 2)); // => false\n        System.out.println("3 != 2? " + (3 != 2)); // => true\n        System.out.println("3 > 2? " + (3 > 2)); // => true\n        System.out.println("3 < 2? " + (3 < 2)); // => false\n        System.out.println("2 <= 2? " + (2 <= 2)); // => true\n        System.out.println("2 >= 2? " + (2 >= 2)); // => true\n\n        // Boolean operators\n        System.out.println("3 > 2 && 2 > 3? " + ((3 > 2) && (2 > 3))); // => false\n        System.out.println("3 > 2 || 2 > 3? " + ((3 > 2) || (2 > 3))); // => true\n        System.out.println("!(3 == 2)? " + (!(3 == 2))); // => true\n\n        // Bitwise operators!\n        /*\n        ~      Unary bitwise complement\n        <<     Signed left shift\n        >>     Signed/Arithmetic right shift\n        >>>    Unsigned/Logical right shift\n        &      Bitwise AND\n        ^      Bitwise exclusive OR\n        |      Bitwise inclusive OR\n        */\n\n        // Increment operators\n        int i = 0;\n        System.out.println("\n->Inc/Dec-rementation");\n        // The ++ and -- operators increment and decrement by 1 respectively.\n        // If they are placed before the variable, they increment then return;\n        // after the variable they return then increment.\n        System.out.println(i++); // i = 1, prints 0 (post-increment)\n        System.out.println(++i); // i = 2, prints 2 (pre-increment)\n        System.out.println(i--); // i = 1, prints 2 (post-decrement)\n        System.out.println(--i); // i = 0, prints 0 (pre-decrement)\n\n        ///////////////////////////////////////\n        // Control Structures\n        ///////////////////////////////////////\n        System.out.println("\n->Control Structures");\n\n        // If statements are c-like\n        int j = 10;\n        if (j == 10) {\n            System.out.println("I get printed");\n        } else if (j > 10) {\n            System.out.println("I don't");\n        } else {\n            System.out.println("I also don't");\n        }\n\n        // While loop\n        int fooWhile = 0;\n        while(fooWhile < 100) {\n            System.out.println(fooWhile);\n            // Increment the counter\n            // Iterated 100 times, fooWhile 0,1,2...99\n            fooWhile++;\n        }\n        System.out.println("fooWhile Value: " + fooWhile);\n\n        // Do While Loop\n        int fooDoWhile = 0;\n        do {\n            System.out.println(fooDoWhile);\n            // Increment the counter\n            // Iterated 99 times, fooDoWhile 0->99\n            fooDoWhile++;\n        } while(fooDoWhile < 100);\n        System.out.println("fooDoWhile Value: " + fooDoWhile);\n\n        // For Loop\n        // for loop structure => for(<start_statement>; <conditional>; <step>)\n        for (int fooFor = 0; fooFor < 10; fooFor++) {\n            System.out.println(fooFor);\n            // Iterated 10 times, fooFor 0->9\n        }\n        System.out.println("fooFor Value: " + fooFor);\n\n        // Nested For Loop Exit with Label\n        outer:\n        for (int i = 0; i < 10; i++) {\n          for (int j = 0; j < 10; j++) {\n            if (i == 5 && j ==5) {\n              break outer;\n              // breaks out of outer loop instead of only the inner one\n            }\n          }\n        }\n\n        // For Each Loop\n        // The for loop is also able to iterate over arrays as well as objects\n        // that implement the Iterable interface.\n        int[] fooList = {1, 2, 3, 4, 5, 6, 7, 8, 9};\n        // for each loop structure => for (<object> : <iterable>)\n        // reads as: for each element in the iterable\n        // note: the object type must match the element type of the iterable.\n        for (int bar : fooList) {\n            System.out.println(bar);\n            //Iterates 9 times and prints 1-9 on new lines\n        }\n\n        // Switch Case\n        // A switch works with the byte, short, char, and int data types.\n        // It also works with enumerated types (discussed in Enum Types), the\n        // String class, and a few special classes that wrap primitive types:\n        // Character, Byte, Short, and Integer.\n        // Starting in Java 7 and above, we can also use the String type.\n        // Note: Do remember that, not adding "break" at end any particular case ends up in\n        // executing the very next case(given it satisfies the condition provided) as well.\n        int month = 3;\n        String monthString;\n        switch (month) {\n            case 1: monthString = "January";\n                    break;\n            case 2: monthString = "February";\n                    break;\n            case 3: monthString = "March";\n                    break;\n            default: monthString = "Some other month";\n                     break;\n        }\n        System.out.println("Switch Case Result: " + monthString);\n\n\n        // Try-with-resources (Java 7+)\n        // Try-catch-finally statements work as expected in Java but in Java 7+\n        // the try-with-resources statement is also available. Try-with-resources\n        // simplifies try-catch-finally statements by closing resources\n        // automatically.\n\n        // In order to use a try-with-resources, include an instance of a class\n        // in the try statement. The class must implement java.lang.AutoCloseable.\n        try (BufferedReader br = new BufferedReader(new FileReader("foo.txt"))) {\n            // You can attempt to do something that could throw an exception.\n            System.out.println(br.readLine());\n            // In Java 7, the resource will always be closed, even if it throws\n            // an Exception.\n        } catch (Exception ex) {\n            //The resource will be closed before the catch statement executes.\n            System.out.println("readLine() failed.");\n        }\n        // No need for a finally statement in this case, the BufferedReader is\n        // already closed. This can be used to avoid certain edge cases where\n        // a finally statement might not be called.\n        // To learn more:\n        // https://docs.oracle.com/javase/tutorial/essential/exceptions/tryResourceClose.html\n\n\n        // Conditional Shorthand\n        // You can use the '?' operator for quick assignments or logic forks.\n        // Reads as "If (statement) is true, use <first value>, otherwise, use\n        // <second value>"\n        int foo = 5;\n        String bar = (foo < 10) ? "A" : "B";\n        System.out.println("bar : " + bar); // Prints "bar : A", because the \n        // statement is true.\n        // Or simply\n        System.out.println("bar : " + (foo < 10 ? "A" : "B"));\n        \n\n        ////////////////////////////////////////\n        // Converting Data Types\n        ////////////////////////////////////////\n\n        // Converting data\n\n        // Convert String To Integer\n        Integer.parseInt("123");//returns an integer version of "123"\n\n        // Convert Integer To String\n        Integer.toString(123);//returns a string version of 123\n\n        // For other conversions check out the following classes:\n        // Double\n        // Long\n        // String\n\n        ///////////////////////////////////////\n        // Classes And Functions\n        ///////////////////////////////////////\n\n        System.out.println("\n->Classes & Functions");\n\n        // (definition of the Bicycle class follows)\n\n        // Use new to instantiate a class\n        Bicycle trek = new Bicycle();\n\n        // Call object methods\n        trek.speedUp(3); // You should always use setter and getter methods\n        trek.setCadence(100);\n\n        // toString returns this Object's string representation.\n        System.out.println("trek info: " + trek.toString());\n\n        // Double Brace Initialization\n        // The Java Language has no syntax for how to create static Collections\n        // in an easy way. Usually you end up in the following way:\n        private static final Set<String> COUNTRIES = new HashSet<String>();\n        static {\n           COUNTRIES.add("DENMARK");\n           COUNTRIES.add("SWEDEN");\n           COUNTRIES.add("FINLAND");\n        }\n\n        // But there's a nifty way to achieve the same thing in an\n        // easier way, by using something that is called Double Brace\n        // Initialization.\n        private static final Set<String> COUNTRIES = new HashSet<String>() {{\n            add("DENMARK");\n            add("SWEDEN");\n            add("FINLAND");\n        }}\n\n        // The first brace is creating a new AnonymousInnerClass and the\n        // second one declares an instance initializer block. This block\n        // is called when the anonymous inner class is created.\n        // This does not only work for Collections, it works for all\n        // non-final classes.\n\n    } // End main method\n} // End LearnJava class\n\n// You can include other, non-public outer-level classes in a .java file,\n// but it is not good practice. Instead split classes into separate files.\n\n// Class Declaration Syntax:\n// <public/private/protected> class <class name> {\n//    // data fields, constructors, functions all inside.\n//    // functions are called as methods in Java.\n// }\n\nclass Bicycle {\n\n    // Bicycle's Fields/Variables\n    public int cadence; // Public: Can be accessed from anywhere\n    private int speed;  // Private: Only accessible from within the class\n    protected int gear; // Protected: Accessible from the class and subclasses\n    String name; // default: Only accessible from within this package\n    static String className; // Static class variable\n\n    // Static block\n    // Java has no implementation of static constructors, but\n    // has a static block that can be used to initialize class variables\n    // (static variables).\n    // This block will be called when the class is loaded.\n    static {\n        className = "Bicycle";\n    }\n\n    // Constructors are a way of creating classes\n    // This is a constructor\n    public Bicycle() {\n        // You can also call another constructor:\n        // this(1, 50, 5, "Bontrager");\n        gear = 1;\n        cadence = 50;\n        speed = 5;\n        name = "Bontrager";\n    }\n    // This is a constructor that takes arguments\n    public Bicycle(int startCadence, int startSpeed, int startGear,\n        String name) {\n        this.gear = startGear;\n        this.cadence = startCadence;\n        this.speed = startSpeed;\n        this.name = name;\n    }\n\n    // Method Syntax:\n    // <public/private/protected> <return type> <function name>(<args>)\n\n    // Java classes often implement getters and setters for their fields\n\n    // Method declaration syntax:\n    // <access modifier> <return type> <method name>(<args>)\n    public int getCadence() {\n        return cadence;\n    }\n\n    // void methods require no return statement\n    public void setCadence(int newValue) {\n        cadence = newValue;\n    }\n    public void setGear(int newValue) {\n        gear = newValue;\n    }\n    public void speedUp(int increment) {\n        speed += increment;\n    }\n    public void slowDown(int decrement) {\n        speed -= decrement;\n    }\n    public void setName(String newName) {\n        name = newName;\n    }\n    public String getName() {\n        return name;\n    }\n\n    //Method to display the attribute values of this Object.\n    @Override // Inherited from the Object class.\n    public String toString() {\n        return "gear: " + gear + " cadence: " + cadence + " speed: " + speed +\n            " name: " + name;\n    }\n} // end class Bicycle\n\n// PennyFarthing is a subclass of Bicycle\nclass PennyFarthing extends Bicycle {\n    // (Penny Farthings are those bicycles with the big front wheel.\n    // They have no gears.)\n\n    public PennyFarthing(int startCadence, int startSpeed) {\n        // Call the parent constructor with super\n        super(startCadence, startSpeed, 0, "PennyFarthing");\n    }\n\n    // You should mark a method you're overriding with an @annotation.\n    // To learn more about what annotations are and their purpose check this\n    // out: http://docs.oracle.com/javase/tutorial/java/annotations/\n    @Override\n    public void setGear(int gear) {\n        this.gear = 0;\n    }\n}\n\n// Object casting\n// Since the PennyFarthing class is extending the Bicycle class, we can say\n// a PennyFarthing is a Bicycle and write :\n// Bicycle bicycle = new PennyFarthing();\n// This is called object casting where an object is taken for another one. There\n// are lots of details and deals with some more intermediate concepts here:\n// https://docs.oracle.com/javase/tutorial/java/IandI/subclasses.html\n\n// Interfaces\n// Interface declaration syntax\n// <access-level> interface <interface-name> extends <super-interfaces> {\n//     // Constants\n//     // Method declarations\n// }\n\n// Example - Food:\npublic interface Edible {\n    public void eat(); // Any class that implements this interface, must\n                       // implement this method.\n}\n\npublic interface Digestible {\n    public void digest();\n    // Since Java 8, interfaces can have default method.\n    public default void defaultMethod() {\n        System.out.println("Hi from default method ...");\n    }\n}\n\n// We can now create a class that implements both of these interfaces.\npublic class Fruit implements Edible, Digestible {\n    @Override\n    public void eat() {\n        // ...\n    }\n\n    @Override\n    public void digest() {\n        // ...\n    }\n}\n\n// In Java, you can extend only one class, but you can implement many\n// interfaces. For example:\npublic class ExampleClass extends ExampleClassParent implements InterfaceOne,\n    InterfaceTwo {\n    @Override\n    public void InterfaceOneMethod() {\n    }\n\n    @Override\n    public void InterfaceTwoMethod() {\n    }\n\n}\n\n// Abstract Classes\n\n// Abstract Class declaration syntax\n// <access-level> abstract class <abstract-class-name> extends\n// <super-abstract-classes> {\n//     // Constants and variables\n//     // Method declarations\n// }\n\n// Abstract Classes cannot be instantiated.\n// Abstract classes may define abstract methods.\n// Abstract methods have no body and are marked abstract\n// Non-abstract child classes must @Override all abstract methods\n// from their super-classes.\n// Abstract classes can be useful when combining repetitive logic\n// with customised behavior, but as Abstract classes require\n// inheritance, they violate "Composition over inheritance"\n// so consider other approaches using composition.\n// https://en.wikipedia.org/wiki/Composition_over_inheritance\n\npublic abstract class Animal\n{\n    private int age;\n\n    public abstract void makeSound();\n\n    // Method can have a body\n    public void eat()\n    {\n        System.out.println("I am an animal and I am Eating.");\n        // Note: We can access private variable here.\n        age = 30;\n    }\n\n    public void printAge()\n    {\n        System.out.println(age);\n    }\n\n    // Abstract classes can have main method.\n    public static void main(String[] args)\n    {\n        System.out.println("I am abstract");\n    }\n}\n\nclass Dog extends Animal\n{\n    // Note still have to override the abstract methods in the\n    // abstract class.\n    @Override\n    public void makeSound()\n    {\n        System.out.println("Bark");\n        // age = 30;    ==> ERROR!    age is private to Animal\n    }\n\n    // NOTE: You will get an error if you used the\n    // @Override annotation here, since java doesn't allow\n    // overriding of static methods.\n    // What is happening here is called METHOD HIDING.\n    // Check out this SO post: http://stackoverflow.com/questions/16313649/\n    public static void main(String[] args)\n    {\n        Dog pluto = new Dog();\n        pluto.makeSound();\n        pluto.eat();\n        pluto.printAge();\n    }\n}\n\n// Final Classes\n\n// Final Class declaration syntax\n// <access-level> final <final-class-name> {\n//     // Constants and variables\n//     // Method declarations\n// }\n\n// Final classes are classes that cannot be inherited from and are therefore a\n// final child. In a way, final classes are the opposite of abstract classes\n// because abstract classes must be extended, but final classes cannot be\n// extended.\npublic final class SaberToothedCat extends Animal\n{\n    // Note still have to override the abstract methods in the\n    // abstract class.\n    @Override\n    public void makeSound()\n    {\n        System.out.println("Roar");\n    }\n}\n\n// Final Methods\npublic abstract class Mammal()\n{\n    // Final Method Syntax:\n    // <access modifier> final <return type> <function name>(<args>)\n\n    // Final methods, like, final classes cannot be overridden by a child\n    // class, and are therefore the final implementation of the method.\n    public final boolean isWarmBlooded()\n    {\n        return true;\n    }\n}\n\n// Enum Type\n//\n// An enum type is a special data type that enables for a variable to be a set\n// of predefined constants. The variable must be equal to one of the values\n// that have been predefined for it. Because they are constants, the names of\n// an enum type's fields are in uppercase letters. In the Java programming\n// language, you define an enum type by using the enum keyword. For example,\n// you would specify a days-of-the-week enum type as:\npublic enum Day {\n    SUNDAY, MONDAY, TUESDAY, WEDNESDAY,\n    THURSDAY, FRIDAY, SATURDAY\n}\n\n// We can use our enum Day like that:\npublic class EnumTest {\n    // Variable Enum\n    Day day;\n\n    public EnumTest(Day day) {\n        this.day = day;\n    }\n\n    public void tellItLikeItIs() {\n        switch (day) {\n            case MONDAY:\n                System.out.println("Mondays are bad.");\n                break;\n            case FRIDAY:\n                System.out.println("Fridays are better.");\n                break;\n            case SATURDAY:\n            case SUNDAY:\n                System.out.println("Weekends are best.");\n                break;\n            default:\n                System.out.println("Midweek days are so-so.");\n                break;\n        }\n    }\n\n    public static void main(String[] args) {\n        EnumTest firstDay = new EnumTest(Day.MONDAY);\n        firstDay.tellItLikeItIs(); // => Mondays are bad.\n        EnumTest thirdDay = new EnumTest(Day.WEDNESDAY);\n        thirdDay.tellItLikeItIs(); // => Midweek days are so-so.\n    }\n}\n\n// Enum types are much more powerful than we show above.\n// The enum body can include methods and other fields.\n// You can see more at https://docs.oracle.com/javase/tutorial/java/javaOO/enum.html\n\n// Getting Started with Lambda Expressions\n//\n// New to Java version 8 are lambda expressions. Lambdas are more commonly found\n// in functional programming languages, which means they are methods which can\n// be created without belonging to a class, passed around as if it were itself\n// an object, and executed on demand.\n//\n// Final note, lambdas must implement a functional interface. A functional\n// interface is one which has only a single abstract method declared. It can\n// have any number of default methods. Lambda expressions can be used as an\n// instance of that functional interface. Any interface meeting the requirements\n// is treated as a functional interface. You can read more about interfaces\n// above.\n//\nimport java.util.Map;\nimport java.util.HashMap;\nimport java.util.function.*;\nimport java.security.SecureRandom;\n\npublic class Lambdas {\n    public static void main(String[] args) {\n        // Lambda declaration syntax:\n\t// <zero or more parameters> -> <expression body or statement block>\n\n        // We will use this hashmap in our examples below.\n        Map<String, String> planets = new HashMap<>();\n            planets.put("Mercury", "87.969");\n            planets.put("Venus", "224.7");\n            planets.put("Earth", "365.2564");\n            planets.put("Mars", "687");\n            planets.put("Jupiter", "4,332.59");\n            planets.put("Saturn", "10,759");\n            planets.put("Uranus", "30,688.5");\n            planets.put("Neptune", "60,182");\n\n        // Lambda with zero parameters using the Supplier functional interface\n        // from java.util.function.Supplier. The actual lambda expression is\n        // what comes after numPlanets =.\n        Supplier<String> numPlanets = () -> Integer.toString(planets.size());\n        System.out.format("Number of Planets: %s\n\n", numPlanets.get());\n\n        // Lambda with one parameter and using the Consumer functional interface\n        // from java.util.function.Consumer. This is because planets is a Map,\n        // which implements both Collection and Iterable. The forEach used here,\n        // found in Iterable, applies the lambda expression to each member of\n        // the Collection. The default implementation of forEach behaves as if:\n        /*\n            for (T t : this)\n                action.accept(t);\n        */\n\n        // The actual lambda expression is the parameter passed to forEach.\n        planets.keySet().forEach((p) -> System.out.format("%s\n", p));\n\n        // If you are only passing a single argument, then the above can also be\n        // written as (note absent parentheses around p):\n        planets.keySet().forEach(p -> System.out.format("%s\n", p));\n\n        // Tracing the above, we see that planets is a HashMap, keySet() returns\n        // a Set of its keys, forEach applies each element as the lambda \n        // expression of: (parameter p) -> System.out.format("%s\n", p). Each\n        // time, the element is said to be "consumed" and the statement(s)\n        // referred to in the lambda body is applied. Remember the lambda body\n        // is what comes after the ->.\n\n        // The above without use of lambdas would look more traditionally like:\n        for (String planet : planets.keySet()) {\n            System.out.format("%s\n", planet);\n        }\n\n        // This example differs from the above in that a different forEach\n        // implementation is used: the forEach found in the HashMap class\n        // implementing the Map interface. This forEach accepts a BiConsumer,\n        // which generically speaking is a fancy way of saying it handles\n        // the Set of each Key -> Value pairs. This default implementation\n        // behaves as if:\n        /*\n            for (Map.Entry<K, V> entry : map.entrySet())\n                action.accept(entry.getKey(), entry.getValue());\n        */\n\n        // The actual lambda expression is the parameter passed to forEach.\n        String orbits = "%s orbits the Sun in %s Earth days.\n";\n        planets.forEach((K, V) -> System.out.format(orbits, K, V));\n\n        // The above without use of lambdas would look more traditionally like:\n        for (String planet : planets.keySet()) {\n            System.out.format(orbits, planet, planets.get(planet));\n        }\n\n        // Or, if following more closely the specification provided by the\n        // default implementation:\n        for (Map.Entry<String, String> planet : planets.entrySet()) {\n            System.out.format(orbits, planet.getKey(), planet.getValue());\n        }\n\n        // These examples cover only the very basic use of lambdas. It might not\n        // seem like much or even very useful, but remember that a lambda can be\n        // created as an object that can later be passed as parameters to other\n        // methods.\n    }\n}\n
  740  curl cheat.sh/ruby/:learn
  741  curl cheat.sh/haskel/:learn
  742  curl cheat.sh/haskel/
  743  curl cheat.sh/haskel/92
  744  curl cheat.sh/js
  745  curl cheat.sh/js/:learn
  746  curl cheat.sh/algebra
  747  curl cheat.sh/grunt
  748  curl cheat.sh/xml
  749  curl cheat.sh/rspec
  750  curl cheat.sh/node
  751  curl cheat.sh/tmux
  752  curl cheat.sh/cython
  753  curl cheat.sh/ipython
  754  de CHEET.vim
  755  curl cheat.sh/elixir
  756  curl cheat.sh/elixir/:learn
  757  curl cheat.sh/css/:learn
  758  curl cheat.sh/css
  759  curl cheat.sh/html
  760  curl cheat.sh/tcl
  761  curl cheat.sh/tcl/
  762  curl cheat.sh/tcl/100
  764  curl cheat.sh/tree
  765  curl cheat.sh/awk
  766  curl cheat.sh/linux
  767  curl cheat.sh/ls
  768  curl cheat.sh/gz
  769  curl cheat.sh/python
  770  curl cheat.sh/:list
  771  curl cheat.sh/apache
  772  curl cheat.sh/apt-cache
  773  curl cheat.sh/ip
  774  curl cheat.sh/ln
  775  curl cheat.sh/cat
  776  curl cheat.sh/tail
  777  curl cheat.sh/less
  778  curl cheat.sh/fopen
  779  curl cheat.sh/flopen
  780  js
  781  curl cheat.sh/lsof
  782  suo su
  783  cp -r jsReact /media/red/A5A1-FBC4
  784  kdeo kBank22Py1.yml
  785  ls LabPuDB
  786  cd LabPuDB/PuLogAndConfPrimes
  787  cd /media/red/
  788  cd C09F-10DF
  789  cp -r 2019PyLink ../C09F-10DF
  790  cp -r BBBLOCK ../C09F-10DF
  791  cp -r git ../C09F-10DF
  792  cd ../pink
  793  cp -r jsReact ../C09F-10DF
  794  rm -r jsReact
  795  cd /media/red/C09F-10DF
  796  cd nodeJS
  797  guil build
  798  guilp build
  799  npm install -g gulp\n
  800  npm install -g gulp\nsudo su
  801  gulp --version
  802  cd Documents
  803  gulp build
  804  cd ntetris
  805  npm install -g ntetris\n
  806  cd node-calendar
  807  npm install node-calendar\n
  808  cd /media/red/C09F-10DF/nodeJS
  809  cd react-clock
  810  yarn add react-clock
  811  cd react-clockwall-master
  812  yarn install -g gulp
  813  yarn global add gulp
  814  cd react-tetris
  815  yarn install
  816  yarn run build
  817  yarn run watch
  818  yarn add npm-run-all\n
  819  yarn start\n
  820  npm run build
  821  cd git/aTest
  822  rm -r aTest
  823  cd /media/red/C09F-10DF/android-studio
  824  chmod +x studio.sh
  825  cd /media/red/pink/android-studio
  826  cd /media/red/pink/jsReact
  827  ls ntetris-master
  828  cat ntetris-master/README.md
  829  cd 4run/react-tetris-master
  830  cd react-todo-master
  831  ls timer-master
  832  cat timer-master/README.md
  833  ccat timer-master/README.md
  834  cd /media/red/64black/android-studio
  835  cd /media/red/pink/jsReact/react-clockwall
  836  cd /media/red/64black/POC/react-clockwall
  837  npm run watch
  838  cd /media/red/64black/POC/react-todo
  839  cd react-tetris-master
  840  cd react-clock-master
  842  ls src/website
  843  ls src/shared
  844  ls sample
  845  ls sample/parcel
  846  cd sample/parcel/
  847  firefox index.html
  848  cd /media/red/64black/POC/react-clock/
  849  cd parcel
  850  de angularJS.vim
  851  cd hello-world
  852  cat README.md
  854  cd ../
  855  cd /media/red/64black/POC/
  856  cd AwesomeProject
  857  cd /media/red/64black/POC/AwesomeProject
  859  rm -r PinkUkr
  860  cd /media/red/A5A1-FBC4
  861  rm -r BBBLOCK
  862  mkdir BBBLOCK
  863  cd POC
  864  history | github
  865  history | grep github
  866  git clone https://github.com/mike-plummer/angular-react-vue-stopwatch.git
  867  cd angular-react-vue-stopwatch
  868  git clone git@github.com:leota/electron-angular4-sqlite3.git
  869  git clone https://github.com/leota/electron-angular4-sqlite3.git
  870  cd ../64black
  871  git clone https://github.com/Mindinventory/Angular6-Example-Website.git
  872  cd Angular6-Example-Website
  873  npm run db
  874  npm run electron
  875  git clone https://github.com/pamtbaau/angular7-electron3-sqlite3-bootstrap4-webpack4.git
  876  cd angular7-electron3-sqlite3-bootstrap4-webpack4
  877  npm instal
  878  npm run ng
  879  npm install -g @angular/cli ng
  880  sudo npm install -g @angular/cli ng
  881  ng serve
  882  npm run build:once
  883  git clone https://github.com/electron/electron-quick-start
  884  cd electron-angular4-sqlite3
  885  npm install && npm start
  886  git clone https://github.com/contentful/the-example-app.nodejs.git
  887  git clone https://github.com/clocklimited/BasicExpressSite
  888  cd BasicExpressSite
  889  cd the-example-app.nodejs
  890  npm run start:dev
  891  git clone https://github.com/catamphetamine/react-website-basic-example
  892  cd react-website-basic-example
  893  npm start
  894  de my.vim
  895  git clone https://github.com/gothinkster/node-express-realworld-example-app
  896  npm run dev
  897  cd node-express-realworld-example-app
  898  git clone https://github.com/kennashka/calculator
  899  cd calculator/
  900  npm install
  901  node app
  902  node app.js
  903  cd Music
  904  rm *.tar.gz
  905  cd /media/red/pink/android-studio/bin
  906  cd /media/red/64black/android-studio/bin
  907  cd android-studio-ide-183.5452501-linux
  908  mv android-studio ..
  909  rm -r android-studio-ide-183.5452501-linux
  910  cd android-studio
  912  cd android-studio/bin
  913  ./studio.sh
  914  cd java-eclipse2/eclipse
  915  ./eclipse
  916  sudo apt-get install gdebi
  917  ls -al
  918  cd /media/red/64black
  920  cd DocFetcher-1.1.22
  921  de Readme.txt
  922  ./DocFetcher-GTK3.sh
  923  cd ../git/bTest
  924  mkdir FVWM
  925  cp /usr/lib/X11/fvwm/system.fvwmrc .
  926  hyper
  927  ls ../kDot/LabGO
  928  ls kDot/LabJAVA
  929  git clone https://github.com/liuxueyang/fvwm-config.git
  930  mv fvwm-config fvwm-config1
  931  git clone https://github.com/110101011/fvwm-config.git
  932  mv fvwm-config fvwm-config2
  933  git clone https://github.com/phleagol/fvwm_2018.git
  934  git clone https://github.com/yaoguai/fvwm-min.git
  935  git clone https://github.com/tcsh-org/tcsh.git
  936  git clone https://github.com/vim/vim.git
  937  git clone https://github.com/neovim/neovim.git
  938  git clone https://github.com/fish-shell/fish-shell.git
  939  git clone https://github.com/zsh-users/zsh.git
  940  git clone https://github.com/bminor/bash.git
  941  git clone https://github.com/ogham/exa.git
  942  git clone https://github.com/ar-/incron.git
  943  git clone https://github.com/BurntSushi/ripgrep.git
  944  git clone git://github.com/wting/autojump.git
  945  git clone https://github.com/sharkdp/fd.git
  946  git clone https://github.com/tmm1/pstree.git
  947  go get github.com/elves/elvish
  948  go get github.com/michaelmacinnis/oh
  949  git clone https://github.com/junegunn/fzf.git
  950  git clone https://github.com/rupa/z.git
  951  fd
  952  kill 23869
  954  make config
  955  ./install-sh
  956  de install-sh
  957  cd fd
  958  cd z
  959  cd incron
  960  make -j8 && sudo make install\n
  961  de out-ist.vim
  962  man incron
  963  cd..
  965  ccat README.md
  969  git clone https://github.com/neurobin/shc.git
  970  git clone https://github.com/PeterDaveHello/ColorEchoForShell.git
  971  git clone https://github.com/MirBSD/mksh.git
  972  git clone https://www.github.com/tgsachse/shellcuts.git
  973  git clone https://github.com/kusabashira/cdf.git
  974  cd cdf
  975  git clone https://github.com/dpremy/dot-ksh.git
  976  git clone https://github.com/mirabilos/shellsnippets.git
  977  git clone https://github.com/loop333/oracle_scripts.git
  978  git clone https://github.com/arismelachroinos/lscript.git
  979  git clone https://github.com/lamerman/shellpy.git
  980  git clone https://github.com/PatrickNicholas/LL-Script.git
  981  git clone https://github.com/chinaran/color-compile.git
  982  git clone https://github.com/breakdance/breakdance.git
  983  git clone https://github.com/sebaste/dotfiles.git
  984  git clone https://github.com/jarun/googler.git
  985  git clone https://github.com/kdabir/has.git
  986  mkdir dot-bot
  987  cd dot-bot
  988  git clone https://github.com/thoughtbot/dotfiles.git
  989  mkdir dot-paul
  990  cd dot-paul
  991  git clone https://github.com/paulirish/dotfiles
  992  git clone https://github.com/supercrabtree/k.git
  993  git clone https://github.com/tmrts/boilr.git
  994  git clone https://github.com/jarun/Buku.git
  995  git clone https://github.com/jarun/pdd.git
  996  cd /media/red/64black/PBin
  997  git clone https://github.com/GNOME/gparted.git
  998  git clone https://github.com/emacs-mirror/emacs
  999  git clone https://github.com/jonas/tig.git
 1000  git clone https://github.com/strace/strace.git
 1001  git clone https://github.com/fwenzel/pdftk.git
 1002  git clone https://github.com/aircrack-ng/aircrack-ng.git
 1003  git clone https://github.com/monochromegane/the_platinum_searcher.git
 1004  git clone https://github.com/Mebus/cupp.git
 1005  git clone https://github.com/apache/crunch.git
 1006  git clone https://github.com/Kumaava/Facial_Emotion_classifier.git
 1007  git clone https://github.com/gtzinos/Image-Search-Engine
 1008  git clone https://github.com/sid0522/ImageComparison.git
 1009  git clone https://github.com/shiv-gpt/Computer-Vision.git
 1010  git clone https://github.com/janbella/opensift.git
 1011  mv Computer-Vision Computer-Vision1
 1012  git clone https://github.com/deepaksn99/Computer-Vision.git
 1013  df
 1014  df -h
 1015  git clone https://github.com/faif/python-patterns.git
 1016  git clone https://github.com/pytorch/pytorch.git
 1017  git clone https://github.com/Avik-Jain/100-Days-Of-ML-Code.git
 1018  git clone https://github.com/morparia-p/Image-Panorama.git
 1019  git clone https://github.com/gtzinos/Image-Search-Engine.git
 1020  git clone https://github.com/faturita/BidimensionalSignalProcessing.git
 1021  l .f
 1022  cd fvwm-min
 1025  l .fvwm
 1026  mv .fvwm fvwm-min
 1027  mkdir .fvwm
 1028  cp .Xdefaults XdefaultsONE
 1029  de XdefaultsONE
 1030  cd fvwm-config1
 1031  cp * ~/.fvwm
 1032  cp -r * ~/.fvwm
 1033  cd git/bTest/FVWM
 1034  mv .fvwm fvwm-ONE
 1035  cp -r fvwm-config2 ~/.fvwm
 1036  mv .fvwm fvwm-TWO
 1037  man fvwm
 1038  ls .fvwm
 1039  cp ../fvwm-min/config config-min
 1040  cp ../fvwm-ONE/config config-ONE
 1041  deo config
 1042  FvwmCommand Restart
 1043  mv config myconfig
 1044  ls /etc/shells
 1045  ls /etc/
 1046  ls /etc/vim
 1047  ls /etc/zsh
 1048  ls /etc/X11
 1049  ls /usr/share/fvwm
 1050  locate fvwm
 1051  cd /usr/bin/fvwm
 1052  ls /usr/bin/fvwm-config
 1053  cd /usr/bin/fvwm-config
 1054  vi /usr/bin/fvwm-menu-desktop
 1055  vi /usr/bin/fvwm-config
 1056  vi myconfig
 1057  sudo vi /usr/bin/fvwm-config
 1058  locate fvwm | vim -
 1059  de /usr/share/fvwm/default-config\n
 1060  ls /usr/share/fvwm/default-config\n
 1061  cd /usr/share/fvwm/default-config\n
 1062  cd -
 1063  cp config configDEF
 1064  vi config
 1065  conky
 1066  amixer
 1067  gnome-calendar
 1068  gnome-shell
 1069  gnome-commander
 1070  xfce4-panel
 1071  de config2DEF
 1072  ls /usr/bin/conky
 1073  cd git/bTest/
 1074  mkdir AWESOME
 1075  cd AWESOME
 1076  git clone https://github.com/pettarin/awesome-config.git
 1077  mv awesome-config awesome-config1
 1078  git clone https://github.com/troglobit/awesome-config.git
 1079  mv awesome-config awesome-config2
 1080  git clone https://github.com/prikhi/awesome-config.git
 1081  mv awesome-config awesome-config3
 1082  g clone https://github.com/dynamotn/awesome-config.git
 1083  mv awesome-config awesome-config4
 1084  g clone https://github.com/tony/awesome-config.git
 1085  mv awesome-config awesome-configMin1
 1086  g clone https://github.com/worron/awesome-config.git
 1087  mv awesome-config awesome-configWorron
 1088  xbattbar
 1089  so
 1090  xapm
 1091  mkdir i3
 1092  g clone https://github.com/CSaratakij/i3wm-desktop-config.git
 1093  mv i3wm-desktop-config i3wm-desktop-config1
 1094  g clone https://github.com/sainathadapa/i3-wm-config.git
 1095  g lone https://github.com/addy-dclxvi/i3-starterpack.git
 1096  mv i3-wm-config i3-wm-config2
 1097  g clone https://github.com/addy-dclxvi/i3-starterpack.git
 1098  cd git/bTest/AWESOME
 1099  cd awesome-configWorron
 1100  firefox
 1101  ls FVWM
 1102  git clone https://github.com/worron/awesome-config.git ~/.config/awesome --recursive
 1103  mkdir FLUX
 1104  cd FLUX
 1105  git clone https://github.com/descara/fluxbox-config.git
 1106  mv fluxbox-config fluxbox-config1
 1107  g clone https://github.com/s3rvac/dotfiles.git
 1108  ls dotfiles
 1109  mv dotfiles s3dotfiles
 1110  g clone https://github.com/skybert/my-little-friends.git
 1111  mv my-little-friends git/bTest/FLUX
 1112  ls git/bTest/FVWM
 1113  g clone https://github.com/schw4b/.fluxbox.git
 1114  la
 1115  mv .fluxbox fluxbox-DOT
 1116  cd ../i3
 1117  cd i3-starterpack
 1118  sudo dry
 1119  su dry
 1120  cd i3-wm-config2
 1121  git clone --recursive git@github.com:sainathadapa/i3-wm-config.git ~/.i3
 1122  cd .config/i3
 1123  ls config
 1124  cat config
 1125  cp -r i3 i3One
 1126  cd i3
 1127  rm comfig
 1128  git clone https://github.com/helge000/i3-config.git
 1129  vm i3-config ..
 1130  mv i3-config ..
 1131  rm -r i3
 1132  mv i3-config i3
 1133  cd git/bTest/i3
 1134  git clone https://github.com/lleweldyn/i3-Desktop.git
 1135  cd ../FVWM
 1136  git clone https://github.com/Minda1975/FVWM-configuration.git
 1137  git clone https://github.com/deftsp/dotfvwm.git
 1138  de add-app.vim
 1139  cd git/bTest/FVWM/fvwm-config1
 1140  cp -r icons ~/.fvwm
 1141  cp -r images ~/.fvwm
 1142  cp config ~/.fvwm/config-01
 1143  file
 1144  xfce4-terminal
 1145  thunar
 1146  de config config-01
 1147  gnome-screenshot
 1148  gnome-terminal
 1149  cd images
 1150  cp wallpaper background
 1151  cp -r wallpaper background
 1152  mkdir bgicons
 1153  cp ~/git/bTest/FVWM/fvwm-config2/config config-02
 1154  de config config-01 config-02
 1155  cp ~/git/bTest/FVWM/fvwm-config2/conf.d conf02.d
 1156  cp -r ~/git/bTest/FVWM/fvwm-config2/conf.d conf02.d
 1157  ls conf02.d
 1158  cp ~/git/bTest/screen.png wallpaper
 1159  cp ~/git/bTest/screen.png background
 1160  cd images/wallpaper
 1161  cd background
 1162  nautilus-desktop
 1163  xfce4-sensors
 1164  xfce4-appfinder
 1165  xfce4-popup-applicationsmenu
 1166  xfce4-settings-manager
 1167  xfce4-taskmanager
 1168  cd git
 1169  imagej w3.png w4.png w5.jpg
 1170  cp ~/git/w* .
 1171  fvwm-menu-headlines
 1172  fvwm-menu-directory
 1173  mkdir upstart
 1174  firef.conf
 1175  de firef.conf
 1176  cd .config/
 1177  man xdotool
 1178  de examples.desktop
 1179  mkdir autostart
 1180  gnome-session
 1181  xde-sm
 1182  de .fvwm/config
 1183  nm-applet
 1184  cp config-ONE config
 1185  cp config-01 config
 1186  cp config-02 config
 1187  cp configDEF config
 1188  nautilus
 1189  cd git/bTest
 1190  cd FVWM
 1191  cd fvwm_2018
 1193  cat 01-General
 1194  cat 22-Root-Menu
 1195  cd dotfvwm
 1196  cat f.buttons
 1197  ls modules
 1198  ls modules/FvwmTransFocus
 1199  cs
 1200  ls scripts
 1201  cd FVWM-configuration
 1202  cp .fvwm dfvwm
 1203  cp -r .fvwm dfvwm
 1204  cd dfvwm
 1205  ls icons
 1206  ls buttons
 1207  cp -r .fvwm ab-tile1-fvwm
 1208  cp -r ab-tile1-fvwm git/bTest
 1209  cd git/
 1210  cp -r bTest /media/red/A5A1-FBC4/BBBLOCK
 1211  cp -r bTest/ab-tile1-fvwm /media/red/A5A1-FBC4/BBBLOCK
 1212  cp -r bTest/ab-tile1-fvwm /media/red/64black/
 1213  cp -r bTest/ /media/red/64black/
 1214  cd ~
 1215  cp -r dfvwm ~/.fvwm
 1216  clear
 1217  cp -r ab-tile1-fvwm .fvwm
 1218  mv config tile1-config
 1219  cd .fvwm/
 1220  de config config5DEF-LongBar
 1221  cd .fvwm/images/wallpaper
 1222  mv configDEF config
 1223  mv config4DEF2BarCS9 config
 1224  cp minYes1-config config
 1225  mv config5DEF-LongBar config
 1226  mv minYes2-config config
 1227  blueman-applet
 1228  de config tile1-config
 1229  cp -r ab2-tile1-fvwm .fvwm
 1230  cp -r .fvwm ab2-tile1-fvwm
 1231  rm -r .fvwm
 1232  cd git/nFVWM
 1233  ld fvwm-tiling-master
 1234  ls fvwm-tiling-master
 1235  cp -r fvwm-tiling-master ~/.fvwm
 1236  mv .fvwm fvwm-TiLE
 1237  mv ab2-tile1-fvwm .fvwm
 1238  kill 8167
 1239  de .Xdefaults
 1241  unity
 1242  kill 8142
 1243  xfce4-session
 1244  xsm
 1245  history | vim -
 1246  cd .config
 1247  cd autostart
 1248  lsa
 1249  ls -a
 1250  de .xsession
 1251  mv config keyPre1Nop-config
 1252  cp key2-config config
 1253  cp tile1-config config
 1254  rm config
 1255  cp config-min config
 1256  cd ~/.fvwm
 1257  de temp
 1258  cd fvwm-TiLE
 1260  cd ab-tile1-fvwm
 1261  de config
 1262  de config tConfig
 1263  cp -r .fvwm ab4-tileBettr-fvwm
 1264  shutdown -r now
 1265  exit
 1267  de config config2DEF
 1269  cp ~/.fvwm/config kConfigFVWM
 1270  cp ~/.xsession kXsession
 1271  de CHEET-BASH.vim
 1272  cp -r .fvwm ab6-tileBettr-fvwm
 1273  zip -r ab6-tileBettr-fvwm.zip .fvwm
 1274  cp ab6-tileBettr-fvwm.zip git/bTest/
 1275  mv AWESOME ..
 1276  mv i3 ..
 1277  mv FVWM ..
 1278  mv ab-tile1-fvwm ..
 1279  de eclipse64Black.vim
 1280  git add k*
 1283  cd .fvwm
 1284  cp config congig6Tille
 1286  de kZshrc19.sh
 1287  deo
 1288  mkdir LabCHEET
 1289  mv CHEET* LabCHEET
 1290  git add LabCHEET/
 1291  cd LabCHEET
 1292  git add CHEET*
 1293  mv FLUX ..
 1295  git status
 1296  git commit -a
 1297  deo kIng19.sh
 1299  git push
 1300  cd kDot
 1301  ls k
 1302  ls k*
 1305  reboot
 1306  startx
 1313  cd git/bTest/kDot
 1315  de kConfigFVWM
 1317  cd ../..
 1319  cp -r .config /media/red/124Black/git/dotRedConfig
 1320  cp -r .vim /media/red/124Black/git/dotRedVim
 1322  ls .*
 1323  vim .viminfo
 1324  de kIng19.sh
 1328  de cc.txt
 1329* whitch nvim
 1330* which nvim
 1331* which deo
 1332* cd ~/nvim-linux64/bin
 1335* ./deonvim
 1338* cd /media/red/64black/
 1339* cp -r PBin ../124Black
 1340* cd ../124Black
 1343* cd PBin
 1345* fish
 1346* cd fish-shell
 1354* rm -r build
 1355* mkdir build
 1356* cd build
 1358* cmake ..
 1360* htop
 1361* cd /media/red/124Black/PBin
 1364* cd neovim
 1372* ./fish
 1374* cd ../124Black/PBin/neovim
 1380* ./configure --prefix =/media/red/124Black/git/mySoft\n
 1381* pwd\n
 1382* ./configure --prefix =/media/red/124Black/git/mySoft/\n
 1392* cd src
 1393* make CMAKE_INSTALL_PREFIX=/media/red/124Black/git/mySoft/\n
 1396* make CMAKE_INSTALL_PREFIX=/media/red/124Black/git/mySoft\n
 1398* mkdir nneo
 1399* make CMAKE_INSTALL_PREFIX=~/nneo\n
 1400* ls nneo
 1407* ..
 1411* cd vim
 1415* de src/INSTALL
 1419* pcd tcsh
 1424* cc
 1427* de BUILDING
 1428* cd tcsh
 1436* cd shc
 1439* ./configure
 1443* ./shc
 1446* chmod +x shc.1
 1447* ./shc.1
 1450* ./autogen.sh
 1454* ls fzf
 1455* cd fzf
 1456* de README.md
 1462* de BUILD.md
 1466* ls bin
 1467* ls src
 1469* cd ..
 1471* cd tig
 1473* make
 1475* make install
 1476* tig
 1477* cd bin
 1481* ./tig
 1482* man vim
 1483* b5deo
 1484* b5deo new.vim
 1485* xclock
 1486* sudo su
 1489* b5deo b5new.vim
 1492* cp fish ../../../git/mySoft
 1495* pwd
 1496* cd /media/red/124Black/git/dotRedConfig
 1499* cd nvim
 1501* cd undoDir
 1502* l
 1503* ls b*
 1504* ls %home%red%git%bTest%kDot%b5new.vim
 1505* history
 1506  c
 1508  cd Hist
 1509  ls
 1510  history | cat redZshHistMai19.sh
