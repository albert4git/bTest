    1  apt-get install synaptic
    2  ./install.sh 
    3  systemback
    4  synaptic
    5  clear
    6  df -h
    7  apt update
    8  vi /etc/eclipse.ini 
    9  cd /
   10  df -h
   11  apt-get install fuse libfuse2 git python3-pip ack-grep -y
   12  apt autoremove
   13  synaptic
   14  df -h
   15  cd /home/
   16  ls
   17  ls Systemback/
   18  ls -al Systemback/
   19  rm -r Systemback/
   20  lh -h
   21  df -h
   22  synaptic
   23  exit
   24  synaptic
   25  rm -r lightline.vim/
   26  ls
   27  exit
   28  clear
   29  ls
   30  rm -r quickrun.vim/
   31  rm -r scratch/
   32  la
   33  cd ..
   34  ls
   35  ls plugged/
   36  ls
   37  ls plugged/
   38  ls bundle/
   39  ls plugged/
   40  cd /
   41  cd /media/red/INTENSO/
   42  ls
   43  systemback
   44  cd /home/
   45  lk
   46  ls -lha
   47  ps -ax|grep eclimd
   48  du -sh
   49  cd ..
   50  du -sh
   51  snap find
   52  man snap
   53  snap --beta find
   54  man snap
   55  snapcraft
   56  apt install snapd
   57  hello
   58  snap install hello
   59  hello
   60  apt install snappy
   61  apt-get install snappy
   62  snap list
   63  snap install snappy
   64  snap find
   65  snap status eclipce
   66  snap info eclipce
   67  snap info eclipse
   68  snap info light box
   69  snap info lightbox
   70  snap info firefox
   71  snap find firefox
   72  man snap
   73  snap install firefox
   74  snap run firefox
   75  snap list
   76  snap run firefox
   77  systemback
   78  snap run communitheme
   79  snap install communitheme
   80  snap refresh
   81  snap communitheme
   82  snap run communitheme
   83  systemback
   84  synaptic
   85  apt-get install golang-go
   86  apt-get install xfce4 
   87  apt-get install DockBarX
   88  apt-get install dockBbarx
   89  apt-get install dockBbar
   90  apt-get install fvwm
   91  exit
   92  apt-get install cowsay
   93  cowsay 'i love ubuntu'
   94  while true; do echo "$(date '+%D %T' | toilet -f term -F border --gay)"; sleep 1; done
   95  exit
   96  apt-get install cscope
   97  apt-get install cscope-el
   98  apt-get install xcscope-el
   99  c
  100  exit
  101  systemback
  102  history 
  103  exit
  104  synaptic
  105  exit
  106  synaptic
  107  exit
  108  synaptic
  109  exit
  110  synaptic
  111  exit
  112  route
  113  if q; exit
  114  exit
  115  synaptic
  116  exit
  117  apt-get install lynx
  118  apt-get install w3m
  119  apt-get install link2
  120  apt-get install linck2
  121  exit
  122  synaptic
  123  /usr/bin/python3 -m pip install thesaurus --user --upgrade
  124  c
  125  clear
  126  apt-get install dictd
  127  apt-get install dict-freedict-eng-spa
  128  apt-get install dict-freedict-eng-ge
  129  apt-get install dict-freedict-eng-de
  130  apt-get install dict-freedict-eng-ger
  131  c
  132  dict -d fd-eng-spa "how are you?"
  133  dict -d fd-eng-spa "how"
  134  apt-get install dict-gcide
  135  apt-get install dict-wn
  136  apt-get install dict-moby-thesaurus
  137  apt-get install dict-freedict-eng-deu
  138  sudo apt-get install dict-freedict-deu-eng
  139  apt-get install dict-freedict-spa-eng
  140  apt-get install dict-stardic
  141  synaptic
  142  c
  143  clear
  144  route
  145  apt install net-tools
  146  sudo apt-get install libdvd-pkg
  147  sudo dpkg-reconfigure libdvd-pkg
  148  sudo apt-get install regionset
  149  regionset
  150  pip3 install neovim
  151  pip3 install --upgrade neovim
  152  exit
  153  synaptic
  154  exit
  155  apt-get update
  156  apt-get install nvim
  157  apt-get install neovim
  158  sudo apt-get install python-neovim
  159  sudo apt-get install python3-neovim
  160  exit
  161  apt-get update
  162  apt install ruby-full
  163  exit
  164  pip install prettytable Mako pyaml dateutils --upgrade
  165  apt install python-pip
  166  pip install prettytable Mako pyaml dateutils --upgrade
  167  exit
  168  trans
  169  apt install translate-shell
  170  c
  171  clear
  172  exit
  173  apt-get install --install-recommends aspell
  174  apt-get install --install-recommends ispell
  175  exit
  176  c
  177  pip install dbgp
  178  exit
  179  pip install Image
  180  c
  181  clear
  182  pip install Image
  183  exit
  184  pip install cv2
  185  exit
  186  sudo apt-get install ranger caca-utils highlight atool w3m poppler-utils mediainfo
  187  exit
  188  pip install jupiter
  189  python -m pip install jupyter
  190  synaptic
  191  c
  192  lear
  193  clear
  194  apt install phpmyadmin php-mbstring php-gettext
  195  phpenmod mbstring
  196  clear
  197  systemctl restart apache2
  198  mysql
  199  mysql -u root -p
  200  exit
  201  mysql -u root -p
  202  clear
  203  php -m | grep mcrypt 
  204  service apache2 restart
  205  vi /etc/apache2/apache2.conf
  206  service apache2 restart
  207  vi /etc/apache2/apache2.conf
  208  pip install statistics
  209  pip install Seaborn
  210  pip install signal
  211  synaptic
  212  apt-get -y install ipython ipython-notebook
  213  pip install jupyter
  214  sudo apt-get clean
  215  apt-get clean
  216  synaptic
  217  exit
  218  synaptic
  219  c
  220  exit
  221  pip install python-language-server
  222  pip install wordnet
  223  synaptic
  224  c
  225  clear
  226  history 
  227  history | vim -
  228  history 
  229  apt-get clean
  230  clear
  231  exit
  232  apt-get clean
  233  pip3 install pynvim
  234  pip install pynvim
  235  pip3 install neovim
  236  pip install pynvim
  237  c
  238  pip3 install pynvim
  239  pip install neovim
  240  python -c "import neovim"
  241  synaptic
  242  photorec 
  243  fdisk -l
  244  fdisk -l | vim -
  245  systemback
  246  apt-get clean
  247  systemback
  248  exit
  249  c
  250  history | vim -
  251  synaptic
  252  pip install pdbpp
  253  pip3 install pdbpp
  254  pip install logging
  255  pip3 install logging
  256  c
  257  clear
  258  exit
  259  c
  260  history | vim -
  261  chmod 777 historyRedRoot.txt 
  262  exit
  263  apt-get update
  264  synaptic
  265  exit
  266  apt-get clean
  267  exit
  268  pip install pudb
  269  exit
  270  rm -r goLab/
  271  exit
  272  apt-get clean
  273  ls
  274  cd bin/
  275  ls
  276  exit
  277  apt-get clean
  278  pip install Django==2.0.5
  279  pip install Django
  280  pip3 install Django
  281  df -h
  282  apt-get install vlc 
  283  apt-get install i3
  284  apt-get install i3status
  285  apt-get install dmenu
  286  apt-get install i3wm
  287  apt-get install feh
  288  apt-get install conky
  289  apt-get install i3status
  290  apt-get install xfce4
  291  snap list
  292  snap remove intellij-idea-community
  293  snap list
  294  apt-get install gfortran
  295  clear
  296  pip3 install thread
  297  pip3 install time
  298  pip install time
  299  pip install orange3
  300  java -jar jython-installer-2.7.0.jar
  301  exit
  302  java -jar jython-installer-2.5.4-rc1.jar 
  303  pip3 install torch
  304  pip3 install pandas
  305  gem install mysql2
  306  apt-get install libmysqlclient-dev
  307  gem install mysql2
  308  pip install mysqldb
  309  pip install pymysql
  310  pip install MySQLdb
  311  pip3 install cymysql
  312  pip3 install blis
  313  apt-get install libmysqlcppconn-dev
  314  apt-get install sqlite3 libsqlite3-dev
  315  apt-get install sqlitebrowser
  316  pip3 install sqlite3
  317  pip install sqlite3
  318  pip3 install sqlite
  319  c
  320  clear
  321  ls
  322  java -jar jython-installer-2.7.0.jar 
  323  exit
  324  c
  325  gem install mysql
  326  gem install dbi
  327  gem install mysql
  328  gem install rails
  329  gem install mysql
  330  gem install sqlight3
  331  gem install sqlite3
  332  pip3 install sqlite3
  333  pip3 install sqlite
  334  pip3 install torch
  335  pip install torch
  336  exit
  337  apt-get clean
  338  pip3 install tourch
  339  pip3 install torch
  340  apt-get install cython cython3
  341  synaptic
  342  exit
  343  gem install fxruby
  344  c
  345  clear
  346  ls
  347  gem install fox16
  348  cd ../../../..
  349  cd  ..
  350  c
  351  pip3 install tourch
  352  pip install tourch
  353  python3 --version
  354  pip3 install https://download.pytorch.org/whl/cpu/torch-1.0.1.post2-cp36-cp36m-linux_x86_64.whl
  355  pip3 install torchvision
  356  pip install scikit-image
  357  exit
  358  c
  359  clear
  360  history | vim -
