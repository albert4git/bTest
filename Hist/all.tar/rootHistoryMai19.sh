    1  apt-get install synaptic
    2  ./install.sh 
    3  systemback
    4  synaptic
    5  clear
    6  df -h
    7  apt update
    8  vi /etc/eclipse.ini 
    9  cd /
   10  df -h
   11  apt-get install fuse libfuse2 git python3-pip ack-grep -y
   12  apt autoremove
   13  synaptic
   14  df -h
   15  cd /home/
   16  ls
   17  ls Systemback/
   18  ls -al Systemback/
   19  rm -r Systemback/
   20  lh -h
   21  df -h
   22  synaptic
   23  exit
   24  synaptic
   25  rm -r lightline.vim/
   26  ls
   27  exit
   28  clear
   29  ls
   30  rm -r quickrun.vim/
   31  rm -r scratch/
   32  la
   33  cd ..
   34  ls
   35  ls plugged/
   36  ls
   37  ls plugged/
   38  ls bundle/
   39  ls plugged/
   40  cd /
   41  cd /media/red/INTENSO/
   42  ls
   43  systemback
   44  cd /home/
   45  lk
   46  ls -lha
   47  ps -ax|grep eclimd
   48  du -sh
   49  cd ..
   50  du -sh
   51  snap find
   52  man snap
   53  snap --beta find
   54  man snap
   55  snapcraft
   56  apt install snapd
   57  hello
   58  snap install hello
   59  hello
   60  apt install snappy
   61  apt-get install snappy
   62  snap list
   63  snap install snappy
   64  snap find
   65  snap status eclipce
   66  snap info eclipce
   67  snap info eclipse
   68  snap info light box
   69  snap info lightbox
   70  snap info firefox
   71  snap find firefox
   72  man snap
   73  snap install firefox
   74  snap run firefox
   75  snap list
   76  snap run firefox
   77  systemback
   78  snap run communitheme
   79  snap install communitheme
   80  snap refresh
   81  snap communitheme
   82  snap run communitheme
   83  systemback
   84  synaptic
   85  apt-get install golang-go
   86  apt-get install xfce4 
   87  apt-get install DockBarX
   88  apt-get install dockBbarx
   89  apt-get install dockBbar
   90  apt-get install fvwm
   91  exit
   92  apt-get install cowsay
   93  cowsay 'i love ubuntu'
   94  while true; do echo "$(date '+%D %T' | toilet -f term -F border --gay)"; sleep 1; done
   95  exit
   96  apt-get install cscope
   97  apt-get install cscope-el
   98  apt-get install xcscope-el
   99  c
  100  exit
  101  systemback
  102  history 
  103  exit
  104  synaptic
  105  exit
  106  synaptic
  107  exit
  108  synaptic
  109  exit
  110  synaptic
  111  exit
  112  route
  113  if q; exit
  114  exit
  115  synaptic
  116  exit
  117  apt-get install lynx
  118  apt-get install w3m
  119  apt-get install link2
  120  apt-get install linck2
  121  exit
  122  synaptic
  123  /usr/bin/python3 -m pip install thesaurus --user --upgrade
  124  c
  125  clear
  126  apt-get install dictd
  127  apt-get install dict-freedict-eng-spa
  128  apt-get install dict-freedict-eng-ge
  129  apt-get install dict-freedict-eng-de
  130  apt-get install dict-freedict-eng-ger
  131  c
  132  dict -d fd-eng-spa "how are you?"
  133  dict -d fd-eng-spa "how"
  134  apt-get install dict-gcide
  135  apt-get install dict-wn
  136  apt-get install dict-moby-thesaurus
  137  apt-get install dict-freedict-eng-deu
  138  sudo apt-get install dict-freedict-deu-eng
  139  apt-get install dict-freedict-spa-eng
  140  apt-get install dict-stardic
  141  synaptic
  142  c
  143  clear
  144  route
  145  apt install net-tools
  146  sudo apt-get install libdvd-pkg
  147  sudo dpkg-reconfigure libdvd-pkg
  148  sudo apt-get install regionset
  149  regionset
  150  pip3 install neovim
  151  pip3 install --upgrade neovim
  152  exit
  153  synaptic
  154  exit
  155  apt-get update
  156  apt-get install nvim
  157  apt-get install neovim
  158  sudo apt-get install python-neovim
  159  sudo apt-get install python3-neovim
  160  exit
  161  apt-get update
  162  apt install ruby-full
  163  exit
  164  pip install prettytable Mako pyaml dateutils --upgrade
  165  apt install python-pip
  166  pip install prettytable Mako pyaml dateutils --upgrade
  167  exit
  168  trans
  169  apt install translate-shell
  170  c
  171  clear
  172  exit
  173  apt-get install --install-recommends aspell
  174  apt-get install --install-recommends ispell
  175  exit
  176  c
  177  pip install dbgp
  178  exit
  179  pip install Image
  180  c
  181  clear
  182  pip install Image
  183  exit
  184  pip install cv2
  185  exit
  186  sudo apt-get install ranger caca-utils highlight atool w3m poppler-utils mediainfo
  187  exit
  188  pip install jupiter
  189  python -m pip install jupyter
  190  synaptic
  191  c
  192  lear
  193  clear
  194  apt install phpmyadmin php-mbstring php-gettext
  195  phpenmod mbstring
  196  clear
  197  systemctl restart apache2
  198  mysql
  199  mysql -u root -p
  200  exit
  201  mysql -u root -p
  202  clear
  203  php -m | grep mcrypt 
  204  service apache2 restart
  205  vi /etc/apache2/apache2.conf
  206  service apache2 restart
  207  vi /etc/apache2/apache2.conf
  208  pip install statistics
  209  pip install Seaborn
  210  pip install signal
  211  synaptic
  212  apt-get -y install ipython ipython-notebook
  213  pip install jupyter
  214  sudo apt-get clean
  215  apt-get clean
  216  synaptic
  217  exit
  218  synaptic
  219  c
  220  exit
  221  pip install python-language-server
  222  pip install wordnet
  223  synaptic
  224  c
  225  clear
  226  history 
  227  history | vim -
  228  history 
  229  apt-get clean
  230  clear
  231  exit
  232  apt-get clean
  233  pip3 install pynvim
  234  pip install pynvim
  235  pip3 install neovim
  236  pip install pynvim
  237  c
  238  pip3 install pynvim
  239  pip install neovim
  240  python -c "import neovim"
  241  synaptic
  242  photorec 
  243  fdisk -l
  244  fdisk -l | vim -
  245  systemback
  246  apt-get clean
  247  systemback
  248  exit
  249  c
  250  history | vim -
  251  synaptic
  252  pip install pdbpp
  253  pip3 install pdbpp
  254  pip install logging
  255  pip3 install logging
  256  c
  257  clear
  258  exit
  259  c
  260  history | vim -
  261  chmod 777 historyRedRoot.txt 
  262  exit
  263  apt-get update
  264  synaptic
  265  exit
  266  apt-get clean
  267  exit
  268  pip install pudb
  269  exit
  270  rm -r goLab/
  271  exit
  272  apt-get clean
  273  ls
  274  cd bin/
  275  ls
  276  exit
  277  apt-get clean
  278  pip install Django==2.0.5
  279  pip install Django
  280  pip3 install Django
  281  df -h
  282  apt-get install vlc 
  283  apt-get install i3
  284  apt-get install i3status
  285  apt-get install dmenu
  286  apt-get install i3wm
  287  apt-get install feh
  288  apt-get install conky
  289  apt-get install i3status
  290  apt-get install xfce4
  291  snap list
  292  snap remove intellij-idea-community
  293  snap list
  294  apt-get install gfortran
  295  clear
  296  pip3 install thread
  297  pip3 install time
  298  pip install time
  299  pip install orange3
  300  java -jar jython-installer-2.7.0.jar
  301  exit
  302  java -jar jython-installer-2.5.4-rc1.jar 
  303  pip3 install torch
  304  pip3 install pandas
  305  gem install mysql2
  306  apt-get install libmysqlclient-dev
  307  gem install mysql2
  308  pip install mysqldb
  309  pip install pymysql
  310  pip install MySQLdb
  311  pip3 install cymysql
  312  pip3 install blis
  313  apt-get install libmysqlcppconn-dev
  314  apt-get install sqlite3 libsqlite3-dev
  315  apt-get install sqlitebrowser
  316  pip3 install sqlite3
  317  pip install sqlite3
  318  pip3 install sqlite
  319  c
  320  clear
  321  ls
  322  java -jar jython-installer-2.7.0.jar 
  323  exit
  324  c
  325  gem install mysql
  326  gem install dbi
  327  gem install mysql
  328  gem install rails
  329  gem install mysql
  330  gem install sqlight3
  331  gem install sqlite3
  332  pip3 install sqlite3
  333  pip3 install sqlite
  334  pip3 install torch
  335  pip install torch
  336  exit
  337  apt-get clean
  338  pip3 install tourch
  339  pip3 install torch
  340  apt-get install cython cython3
  341  synaptic
  342  exit
  343  gem install fxruby
  344  c
  345  clear
  346  ls
  347  gem install fox16
  348  cd ../../../..
  349  cd  ..
  350  c
  351  pip3 install tourch
  352  pip install tourch
  353  python3 --version
  354  pip3 install https://download.pytorch.org/whl/cpu/torch-1.0.1.post2-cp36-cp36m-linux_x86_64.whl
  355  pip3 install torchvision
  356  pip install scikit-image
  357  exit
  358  c
  359  clear
  360  history | vim -
  361  chmod 777 rootHistoryMar19.sh 
  362  la
  363  ll
  364  exit
  365  synaptic
  366  apt-get install tig
  367  synaptic
  368  p
  369  pip3 install scikit-image
  370  pip3 install torch
  371  exit
  372  synaptic
  373  apt install docker-ce
  374  apt-cache policy docker-ce
  375  apt install docker-ce
  376  pip install rotate-backups
  377  pip install bakthat
  378  synaptic
  379  c
  380  clear
  381  gem install solargraph -v 0.18.0
  382  pip install solargraph-utils.py --user
  383  yard gems 
  384  apt-get install cppman
  385  exit
  386  apt-get install tern
  387  apt-get install ternjs
  388  synaptic
  389  nodejs -v
  390  synaptic
  391  curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.34.0/install.sh | bash
  392  nvm --version
  393  exit
  394  nvm --version
  395  npm -v
  396  apt instal npm
  397  apt install npm
  398  apt install npm --fix-missing
  399  npm
  400  composer global require mkusher/padawan
  401  apt install composer
  402  composer global require mkusher/padawan
  403  exit
  404  apt-get install php5-sqlite
  405  apt-get install php5-sqlite3
  406  synaptic
  407  apt-get update
  408  apt install npm
  409  apt install npm --fix-missing
  410  npm tern
  411  apt install npm
  412  synaptic
  413  apt-get clean
  414  npm install -g create-react-app
  415  npm install --save react-native-sqlite-storage
  416  npm install --save tern
  417  npm install --save ternjs
  418  which tern
  419  exit
  420  c
  421  clear
  422  npm install
  423  cd -
  424  cd ..
  425  cd git/
  426  ls
  427  cd jsReact/
  428  c
  429  clear
  430  npm install -g expo-cli
  431  apt-get clean
  432  npm install -g yarn
  433  apt-get clean
  434  history 
  435  synaptic
  436  exit
  437  bleachbit 
  438  exit
  439  apt-get install cmus
  440  apt-get install ccat
  441  wget https://github.com/jingweno/ccat/releases/download/v1.1.0/linux-amd64-1.1.0.tar.gz 
  442  tar xfz linux-amd64-1.1.0.tar.gz 
  443  ls
  444  cp linux-amd64-1.1.0/ccat /usr/local/bin/
  445  chmod +x /usr/local/bin/ccat
  446  exit
  447  apt-get clean
  448  yarn global add deepl-translator-cli
  449  exit
  450  apt-get install deepl-translate
  451  exit
  452  pip install deepl-translate
  453  pip3 install deepl-translate
  454  synaptic
  455  apt-get install libtranslate-bin
  456  apt-get install dict-freedict-eng-rus
  457  apt-get install dict-stardic
  458  apt-get install dict-xdic
  459  apt-get install dict-freedict-deu-fra
  460  apt-get install dict-freedict-eng-fra
  461  pip install deepl
  462  pip3 install deepl
  463  exit
  464  clear
  465  pip install thesaurus --user --upgrade
  466  pip3 install thesaurus --user --upgrade
  467  cd ..
  468  /usr/bin/python3 -m pip install thesaurus --user --upgrade
  469  synaptic
  470  exit
  471  apt-get install flex bison libmpfr-dev libgmp-dev make gcc
  472  pip install ply
  473  pip3 install ply
  474  c
  475  history | grep torch
  476  pip3 install torch
  477  pip install torch
  478  pip install django-debug-toolbar-django13
  479  pip3 install django-debug-toolbar-django13
  480  exit
  481  apt-get install fzy
  482  pip install scikits-image
  483  pip3 install scikits-image
  484  pip install scikits
  485  pip install -U scikit-learn
  486  pip install -U scikit-image
  487  pip3 install -U scikit-image
  488  pip3 install -U scikit-learn
  489  pip3 install -U torch
  490  apt-get clean
  491  pip3 install -U torch
  492  npm install livepython -g
  493  c
  494  clear
  495  l
  496  make
  497  ls -al
  498  ./install-sh 
  499  ccat autogen.sh 
  500  ./autogen.sh 
  501  ./configure 
  502  make
  503  make install
  504  ls
  505  colortail config.log 
  506  c
  507  exit
  508  pip3 install -U scikit-statsmodel
  509  pip3 install -U scikit-statsmodels
  510  pip install -U scikits.statsmodels
  511  pip3 install -U scikits.statsmodels
  512  pip3 install -U scikits-statsmodels
  513  pip install -U cProfile
  514  pip3 install -U cProfile
  515  pip install cprofilev
  516  pip3 install cprofilev
  517  pip install gprof2dot
  518  pip3 install gprof2dot
  519  apt-get install ccze
  520  npm install -g pkg
  521  cd ../..
  522  npm install signale
  523  npm install console-log-level
  524  npm install -g pkg
  525  npm install chalk
  526  npm install algebra
  527  npm install --save jimp
  528  apt-get clean
  529  exit
  530  npm install -g bower
  531  exit
  532  apt-get install vidcutter
  533  synaptic
  534  apt-get install mkvmerge
  535  apt-get install ffmpeg
  536  exit
  537  npm install react-clock
  538  gem install 'green_shoes'
  539  apt-get install ruby-dev
  540  gem install 'green_shoes'
  541  apt-get install ruby1.9.1-dev
  542  apt-get install zlibc zlib1g zlib1g-dev
  543  gem install 'green_shoes'
  544  apt-get clean
  545  npm install sqlite3
  546  npm install mocha
  547  npm install mysql
  548  npm install --save better-sqlite3
  549  apt-get clean
  550  c
  551  sudo apt install qemu-kvm
  552  adduser red kvm
  553  chown red /dev/kvm
  554  exit
  555  c
  556  clear
  557  gem install 'green_shoes'
  558  pip3 install -U torch
  559  apt-get clean
  560  npm install cli-table
  561  npm install tty-table
  562  npm install sql.js
  563  npm install dblite
  564  pip3 install -U pytest
  565  pip install -U pytest
  566  chown red /dev/kvm
  567  apt-get clean
  568  cd git/jsReact/
  569  c
  570  ls
  571  rm -r 2run/
  572  c
  573  clear
  574  ls
  575  rm -r clock-component-master
  576  c
  577  clear
  578  ls
  579  apt-get clean
  580  cd ..
  581  cd jsReact/
  582  c
  583  clear
  584  ls
  585  cd ..
  586  rm -r jsReact/
  587  cp -r jsReact/ /media/red/C09F-10DF/
  588  apt-get clean
  589  exit
  590  npm install -g gulp
  591  c
  592  clear
  593  npm install -g gulp
  594  npm run build
  595  gulp build
  596  chown red /dev/kvm
  597  apt-get clean
  598  c
  599  history | grep kvm
  600  adduser red kvm
  601  chown red /dev/kvm
  602  npm install -g gulp
  603  chown red /dev/kvm
  604  apt-get clean
  605  chown red /dev/kvm
  606  rm -r BBBLOCK/
  607  exit
  608  apt-get clean
  609  exit
  610  exit
  611  apt-get clean
  612  exit
  613  abc
  614  apt-get install gdebi
  615  sudo dpkg --configure -a
  616  apt-get install gdebi
  617  wget https://hyper-updates.now.sh/download/linux_deb
  618  gdebi linux_deb
  619  cd ..
  620  cd Downloads/
  621  l
  622  dpkg -i hyper_2.1.2_amd64.deb 
  623  cp /usr/lib/fvwm/
  624  ls /usr/lib/fvwm/
  625  ls /usr/lib/fvwm/2.6.7/
  626  apt-get install menu
  627  apt --fix-broken install
  628  exit
  629  synaptic
  630  sudo apt-get install postgis sudo apt-get install postgis-gui
  631  sudo apt-get install postgis
  632  sudo apt-get install postgis-gui
  633  man reboot
  634  reboot -p
  635  chown red config
  636  l
  637  vi config 
  638  cp config /home/red/.fvwm/ 
  639  vi config 
  640  apt-get install xdotool
  641  apt-get install awesome
  642  apt-get install awesome-extra
  643  apt-get install xbatt
  644  apt-get install xbattbar
  645  apt-get install xapm
  646  apt-get install Fluxbox
  647  apt-get install fluxbox
  648  reboot -p
  649  sudo apt-get install i3-wm dunst i3lock i3status suckless-tools
  650  sudo apt-get install compton hsetroot rxvt-unicode xsel rofi fonts-noto fonts-mplus xsettingsd lxappearance scrot viewnior
  651  useradd dry
  652  passwd dry
  653  reboot 
  654  apt-get install wmcpuload wmsystemtray wmmemload wmMoonClock wmclockmon fbxkb volumeicon
  655  apt-get install wmcpuload
  656  exit
  657  vi .desktop
  658  mv .desktop a.desktop 
  659  exit
  660  reboot 
  661  apt-get install wmcpuload wmsystemtray wmmemload wmMoonClock wmclockmon fbxkb volumeicon
  662  apt-get install wmcpuload
  663  apt-get install blueman
  664  apt-get insta fbxkb volumeicon
  665  apt-get instal fbxkb volumeicon
  666  apt-get install fbxkb volumeicon
  667  apt-get install wmMoonClock
  668  c
  669  synaptic
  670  reboot
  671  history | cat > rootHistoryMai19.sh 
